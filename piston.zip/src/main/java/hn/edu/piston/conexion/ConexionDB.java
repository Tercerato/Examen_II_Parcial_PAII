/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Alexander
 */
public class ConexionDB {

private static final String URL = "jdbc:sqlserver://localhost:1433;"
        + "databaseName=PISTON;"
        + "encrypt=true;"
        + "trustServerCertificate=true;";

private static final String USER = "sa";
private static final String PASSWORD = "ProgramacionavanzadaII";

    private static Connection conexion = null;

    private ConexionDB() {
    }

    public static Connection getConexion() {
        try {
            if (conexion == null || conexion.isClosed()) {

                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

                conexion = DriverManager.getConnection(URL, USER, PASSWORD);
                
                System.out.println("Base de datos conectada: "
                        + conexion.getCatalog());

                System.out.println("Servidor: "
                        + conexion.getMetaData().getURL());

                System.out.println("Conexion exitosa a SQL Server.");
            }

        } catch (ClassNotFoundException e) {
            System.err.println("No se encontro el driver SQL Server: "
                    + e.getMessage());

        } catch (SQLException e) {
            System.err.println("Error al conectar con SQL Server: "
                    + e.getMessage());
        }

        return conexion;
    }

    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("Conexion SQL cerrada.");
            }

        } catch (SQLException e) {
            System.err.println("Error al cerrar conexion: "
                    + e.getMessage());
        }
    }
}