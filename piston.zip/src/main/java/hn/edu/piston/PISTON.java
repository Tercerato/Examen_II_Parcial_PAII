/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * to change this license
 */

package hn.edu.piston;

import hn.edu.piston.principal.Login;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*
 *
 * @author Alexander
 */
public class PISTON extends Application {

    @Override
    public void start(Stage stage) {

        // Crear pantalla de acceso
        Login login = new Login();

        // Configurar escena
        Scene escena = new Scene(login, 1280, 720);

        // Cargar estilos CSS
        var recurso = getClass().getResource(
                "/hn/piston/estilos/estilos.css"
        );

        if (recurso != null) {
            escena.getStylesheets().add(recurso.toExternalForm());
            System.out.println("CSS cargado correctamente.");
        } else {
            System.out.println("ERROR: No se encontró estilos.css");
        }

        // Configurar ventana principal
        stage.setTitle("P.I.S.T.O.N. | Sistema de Gestión Automotriz");
        stage.setScene(escena);

        stage.setMinWidth(1100);
        stage.setMinHeight(650);

        stage.centerOnScreen();
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}