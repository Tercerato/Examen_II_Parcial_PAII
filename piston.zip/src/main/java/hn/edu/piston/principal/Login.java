/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.principal;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.StackPane;
import hn.edu.piston.dao.impl.UsuarioDAOImpl;
import hn.edu.piston.modelo.Usuario;
import javafx.scene.Scene;
import javafx.stage.Stage;
/**
 *
 * @author Alexander
 */
public class Login extends StackPane {

    private TextField txtUsuario;
    private PasswordField txtContrasena;
    private Button btnIngresar;

    public Login() {
        construirInterfaz();
    }

    private void construirInterfaz() {

        // fondo del civic
        Image imagenFondo = new Image(
                getClass().getResourceAsStream(
                        "/hn/piston/imagenes/login-fondo.png"
                )
        );

        ImageView fondo = new ImageView(imagenFondo);
        fondo.setPreserveRatio(false);
        fondo.fitWidthProperty().bind(widthProperty());
        fondo.fitHeightProperty().bind(heightProperty());

        
        /*
        // capita oscura
        Region oscurecimiento = new Region();
        oscurecimiento.setStyle(
                "-fx-background-color: rgba(0,0,0,0.38);"
        );
        */
        
        

        // panel izquierdo
        VBox panel = new VBox(18);
        panel.setAlignment(Pos.CENTER);
        panel.setPadding(new Insets(35));
        panel.setMaxWidth(480);
        panel.setMaxHeight(Region.USE_PREF_SIZE);

        panel.setStyle(
                "-fx-background-color: rgba(10,10,14,0.94);" +
                "-fx-background-radius: 20;" +
                "-fx-border-color: rgba(230,0,20,0.75);" +
                "-fx-border-radius: 20;" +
                "-fx-border-width: 1.2;"
        );

        // logoo
        Image imagenLogo = new Image(
                getClass().getResourceAsStream(
                        "/hn/piston/imagenes/logo-principal.png"
                )
        );

        ImageView logo = new ImageView(imagenLogo);
        logo.setPreserveRatio(true);
        logo.setFitWidth(350);
        logo.setSmooth(true);

        // titulo de propiedad
        Label lblAcceso = new Label("ACCESO AL SISTEMA");
        lblAcceso.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        lblAcceso.setTextFill(Color.web("#ff202f"));

        Label lblBienvenido = new Label("Bienvenido");
        lblBienvenido.setFont(Font.font("Arial", FontWeight.BOLD, 32));
        lblBienvenido.setTextFill(Color.WHITE);

        Label lblDescripcion = new Label(
                "Ingrese sus credenciales para continuar"
        );
        lblDescripcion.setFont(Font.font("Arial", 14));
        lblDescripcion.setTextFill(Color.web("#b8b8bd"));

        // campo usuario con icono
        Label iconoUsuario = new Label("♙");
        iconoUsuario.setStyle(
                "-fx-text-fill: #e60020;" +
                "-fx-font-size: 22px;"
        );

        txtUsuario = new TextField();
        txtUsuario.setPromptText("Usuario");
        txtUsuario.setPrefHeight(48);
        txtUsuario.setStyle(estiloCampo());

        HBox campoUsuario = new HBox(12, iconoUsuario, txtUsuario);
        campoUsuario.setAlignment(Pos.CENTER_LEFT);
        campoUsuario.setPadding(new Insets(0, 12, 0, 12));
        campoUsuario.setStyle(
                "-fx-background-color: #202025;" +
                "-fx-background-radius: 12;" +
                "-fx-border-color: #35353d;" +
                "-fx-border-radius: 12;"
        );

        HBox.setHgrow(txtUsuario, Priority.ALWAYS);
        txtUsuario.setMaxWidth(Double.MAX_VALUE);
        txtUsuario.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: white;" +
                "-fx-prompt-text-fill: #92929b;"
        );

        //campo contraseña con icono
        Label iconoCandado = new Label("🔒");
        iconoCandado.setStyle("-fx-font-size: 18px;");

        txtContrasena = new PasswordField();
        txtContrasena.setPromptText("Contraseña");
        txtContrasena.setPrefHeight(48);
        txtContrasena.setStyle(estiloCampo());

        HBox campoContrasena = new HBox(
                12, iconoCandado, txtContrasena
        );
        campoContrasena.setAlignment(Pos.CENTER_LEFT);
        campoContrasena.setPadding(new Insets(0, 12, 0, 12));
        campoContrasena.setStyle(
                "-fx-background-color: #202025;" +
                "-fx-background-radius: 12;" +
                "-fx-border-color: #35353d;" +
                "-fx-border-radius: 12;"
        );

        HBox.setHgrow(txtContrasena, Priority.ALWAYS);
        txtContrasena.setMaxWidth(Double.MAX_VALUE);
        txtContrasena.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: white;" +
                "-fx-prompt-text-fill: #92929b;"
        );

     /* por los momentos no lo implementare
        //  enseñar / ocultar contraseña
        CheckBox mostrarContrasena = new CheckBox("Mostrar");
        mostrarContrasena.setStyle(
                "-fx-text-fill: #b8b8bd;" +
                "-fx-font-size: 11px;"
        );

        mostrarContrasena.setOnAction(e -> {
            if (mostrarContrasena.isSelected()) {
                txtContrasena.setPromptText(
                        "La contraseña está oculta en este campo"
                );
            } else {
                txtContrasena.setPromptText("Contraseña");
            }
        });

*/

        // btn ingresar
        btnIngresar = new Button("INICIAR SESIÓN");
        btnIngresar.setMaxWidth(Double.MAX_VALUE);
        btnIngresar.setPrefHeight(50);
        btnIngresar.setFont(Font.font("Arial", FontWeight.BOLD, 16));

        btnIngresar.setStyle(
                "-fx-background-color: #e60020;" +
                "-fx-text-fill: white;" +
                "-fx-background-radius: 12;" +
                "-fx-cursor: hand;"
        );

        btnIngresar.setOnMouseEntered(e ->
                btnIngresar.setStyle(
                        "-fx-background-color: #ff2038;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 12;" +
                        "-fx-cursor: hand;"
                )
        );

        btnIngresar.setOnMouseExited(e ->
                btnIngresar.setStyle(
                        "-fx-background-color: #e60020;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 12;" +
                        "-fx-cursor: hand;"
                )
        );

        // que significa
        Label lblSignificado = new Label(
                "P.I.S.T.O.N.\n" +
                "Plataforma Inteligente de Servicio,\n" +
                "Taller, Overhaul y de reparación"
        );

        lblSignificado.setWrapText(true);
        lblSignificado.setTextFill(Color.web("#d0d0d0"));
        lblSignificado.setFont(Font.font("Arial", 12));
        lblSignificado.setAlignment(Pos.CENTER);
        lblSignificado.setTextAlignment(
                javafx.scene.text.TextAlignment.CENTER
        );

        // organización
        panel.getChildren().addAll(
        logo,
        lblAcceso,
        lblBienvenido,
        lblDescripcion,
        campoUsuario,
        campoContrasena,
       // mostrarContrasena,
        btnIngresar,
        lblSignificado
        );

        // accion del boton
        btnIngresar.setOnAction(e -> validarCampos());

        // ubicar el panel
        StackPane.setAlignment(panel, Pos.CENTER_LEFT);
        StackPane.setMargin(panel, new Insets(35, 0, 35, 60));

        // pantalla
        getChildren().addAll(
                fondo,
               // oscurecimiento,
                panel
        );
    }

    private String estiloCampo() {
        return "-fx-background-color: #202025;" +
               "-fx-text-fill: white;" +
               "-fx-prompt-text-fill: #92929b;" +
               "-fx-background-radius: 12;" +
               "-fx-border-color: #35353d;" +
               "-fx-border-radius: 12;" +
               "-fx-border-width: 1;" +
               "-fx-padding: 10 15;";
    }

private void validarCampos() {

    String usuario = txtUsuario.getText().trim();
    String contrasena = txtContrasena.getText();

    if (usuario.isEmpty() || contrasena.isEmpty()) {

        Alert alerta = new Alert(Alert.AlertType.WARNING);
        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText("Campos incompletos");
        alerta.setContentText(
                "Ingrese su usuario y contraseña."
        );
        alerta.showAndWait();

        return;
    }

    UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();

    Usuario usuarioAutenticado =
            usuarioDAO.autenticar(usuario, contrasena);

    if (usuarioAutenticado != null) {

Dashboard dashboard = new Dashboard();

Scene escena = new Scene(dashboard, 1280, 720);

// Aplicar CSS al Dashboard
var css = getClass().getResource(
        "/hn/piston/estilos/estilos.css"
);

if (css != null) {
    escena.getStylesheets().add(css.toExternalForm());
} else {
    System.out.println("No se encontró el CSS del Dashboard");
}

// Obtener ventana actual
Stage escenario = (Stage) getScene().getWindow();

escenario.setScene(escena);
escenario.setTitle("P.I.S.T.O.N. - Dashboard");
escenario.centerOnScreen();

    } else {

        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText("Acceso denegado");
        alerta.setContentText(
                "Usuario o contraseña incorrectos, "
                + "o cuenta desactivada."
        );
        alerta.showAndWait();

        txtContrasena.clear();
        txtContrasena.requestFocus();
    }
}
}