/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.principal;
import hn.edu.piston.vista.paneles.PanelClientes;
import hn.edu.piston.vista.paneles.PanelVehiculos;
import hn.edu.piston.vista.paneles.PanelMecanicos;
import hn.edu.piston.vista.paneles.PanelOrdenes;
import hn.edu.piston.vista.paneles.PanelInventario;
import hn.edu.piston.vista.paneles.PanelFinanzas;
import hn.edu.piston.vista.paneles.PanelDiagnosticos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import hn.edu.piston.vista.paneles.PanelServicios;
import hn.edu.piston.vista.paneles.PanelUsuarios;
/**
 *
 * @author Alexander
 */
public class Dashboard extends BorderPane {

    private BorderPane contenido;
    private Label tituloModulo;
    private Label subtituloModulo;

    public Dashboard() {
        construirInterfaz();
    }

    private void construirInterfaz() {

        var css = getClass().getResource("/hn/piston/estilos/piston.css"
        );

        if (css != null) {
            getStylesheets().add(css.toExternalForm());
        }

        setStyle(
                "-fx-background-color: #08080b;"
                + "-fx-background-image: url('/hn/piston/imagenes/carretera.png');"
                + "-fx-background-repeat: no-repeat;"
                + "-fx-background-position: center center;"
                + "-fx-background-size: cover;"
        );

        setLeft(crearSidebar());

        // AREA PRINCIPAL
        VBox areaPrincipal = new VBox(15);
        areaPrincipal.setPadding(new Insets(30));
        areaPrincipal.setStyle("-fx-background-color: transparent;");

        // ENCABEZADO
        tituloModulo = new Label("Inicio");
        tituloModulo.setStyle(
                "-fx-text-fill: #f5f5f7;"
                + "-fx-font-size: 26px;"
                + "-fx-font-weight: bold;"
        );

        subtituloModulo = new Label(
                "Bienvenido al centro de operaciones de P.I.S.T.O.N."
        );
        subtituloModulo.setStyle("-fx-text-fill: #777781;");

        // CONTENIDO
        contenido = new BorderPane();
        contenido.setPadding(new Insets(20));

        contenido.setStyle(
                "-fx-background-color: #0f0f14;"
                + "-fx-background-radius: 12;"
                + "-fx-border-color: rgba(255,48,79,0.35);"
                + "-fx-border-radius: 12;"
                + "-fx-border-width: 1;"
        );

        contenido.setMaxWidth(Double.MAX_VALUE);
        contenido.setMaxHeight(Double.MAX_VALUE);

        areaPrincipal.getChildren().addAll(
                tituloModulo,
                subtituloModulo,
                contenido
        );

        VBox.setVgrow(
                contenido,
                javafx.scene.layout.Priority.ALWAYS
        );

        setCenter(areaPrincipal);
    }



    private VBox crearSidebar() {

        VBox sidebar = new VBox(15);
        sidebar.setPrefWidth(250);
        sidebar.setPadding(new Insets(30, 20, 30, 20));

        sidebar.setStyle(
                "-fx-background-color: #0a0a0e;"
                + "-fx-border-color: #292930;"
                + "-fx-border-width: 0 1 0 0;"
        );

        // LOGO
        Image imagenLogo = new Image(
                getClass().getResourceAsStream(
                        "/hn/piston/imagenes/logo-principal.png"
                )
        );

        ImageView logo = new ImageView(imagenLogo);
        logo.setFitWidth(200);
        logo.setPreserveRatio(true);

        Label descripcion = new Label(
                "AUTOMOTIVE MANAGEMENT"
        );

        descripcion.setStyle(
                "-fx-text-fill: #777781;"
                + "-fx-font-size: 11px;"
        );

        VBox identidad = new VBox(10, logo, descripcion);
        identidad.setPadding(new Insets(0, 0, 30, 5));

        Label sistema = new Label("SISTEMA DE GESTIÓN");
        sistema.setStyle(
                "-fx-text-fill: #777781;"
                + "-fx-font-size: 12px;"
        );

        // BOTONES
        Button inicio = crearBoton("⌂   Inicio");
        Button clientes = crearBoton("♙   Clientes");
        Button vehiculos = crearBoton("🚘   Vehículos");
        Button ordenes = crearBoton("⚙   Órdenes de trabajo");
        Button mecanicos = crearBoton("🔧   Mecánicos");
        Button inventario = crearBoton("▦   Inventario");
        Button finanzas = crearBoton("＄   Finanzas");
        Button diagnosticos = crearBoton("⚕   Diagnósticos");
        Button servicios = crearBoton("🔩   Servicios");

        // NAVEGACION
        inicio.setOnAction(e -> mostrarModulo("Inicio"));
        clientes.setOnAction(e -> mostrarModulo("Clientes"));
        vehiculos.setOnAction(e -> mostrarModulo("Vehículos"));
        ordenes.setOnAction(e -> mostrarModulo("Órdenes de trabajo"));
        mecanicos.setOnAction(e -> mostrarModulo("Mecánicos"));
        inventario.setOnAction(e -> mostrarModulo("Inventario"));
        finanzas.setOnAction(e -> mostrarModulo("Finanzas"));
        diagnosticos.setOnAction(e -> mostrarModulo("Diagnósticos"));
        servicios.setOnAction(e -> mostrarModulo("Servicios"));
        
        
        // AGREGAR BOTONES AL SIDEBAR
        sidebar.getChildren().addAll(
                identidad,
                sistema,
                inicio,
                clientes,
                vehiculos,
                ordenes,
                mecanicos,
                inventario,
                finanzas,
                diagnosticos,
                servicios
        );

        return sidebar;
    }


    private Button crearBoton(String texto) {

        Button boton = new Button(texto);

        boton.setMaxWidth(Double.MAX_VALUE);
        boton.setPrefHeight(45);
        boton.setAlignment(Pos.CENTER_LEFT);

        boton.setStyle(
                "-fx-background-color: transparent;"
                + "-fx-text-fill: #a5a5ad;"
                + "-fx-font-size: 14px;"
                + "-fx-background-radius: 8;"
                + "-fx-padding: 12 18;"
                + "-fx-cursor: hand;"
        );

        boton.setOnMouseEntered(e -> boton.setStyle(
                "-fx-background-color: #251216;"
                + "-fx-text-fill: #ff4b5c;"
                + "-fx-font-size: 14px;"
                + "-fx-background-radius: 8;"
                + "-fx-padding: 12 18;"
                + "-fx-cursor: hand;"
        ));

        boton.setOnMouseExited(e -> boton.setStyle(
                "-fx-background-color: transparent;"
                + "-fx-text-fill: #a5a5ad;"
                + "-fx-font-size: 14px;"
                + "-fx-background-radius: 8;"
                + "-fx-padding: 12 18;"
                + "-fx-cursor: hand;"
        ));

        return boton;
    }


    private void mostrarModulo(String nombre) {

        VBox panel = new VBox(15);

        switch (nombre) {

            case "Inicio":

    tituloModulo.setText("Administración de usuarios");

    subtituloModulo.setText(
            "Gestión de cuentas y acceso al sistema P.I.S.T.O.N."
    );

    contenido.setCenter(new PanelUsuarios());
    return;
    


            case "Clientes":

                tituloModulo.setText("Gestión de clientes");

                subtituloModulo.setText(
                        "Administración de clientes registrados en P.I.S.T.O.N."
                );

                contenido.setCenter(new PanelClientes());
                return;

            case "Vehículos":

                tituloModulo.setText("Gestión de vehículos");

                subtituloModulo.setText(
                        "Administración de vehículos de P.I.S.T.O.N."
                );

                contenido.setCenter(new PanelVehiculos());
                return;

            case "Mecánicos":

                tituloModulo.setText("Gestión de mecánicos");

                subtituloModulo.setText(
                        "Administración del personal del taller."
                );

                contenido.setCenter(new PanelMecanicos());
                return;

            case "Órdenes de trabajo":

                tituloModulo.setText("Órdenes de trabajo");

                subtituloModulo.setText(
                        "Administración de órdenes de reparación."
                );

                contenido.setCenter(new PanelOrdenes());
                return;

            case "Inventario":

                tituloModulo.setText("Inventario");

                subtituloModulo.setText(
                        "Administración de repuestos de P.I.S.T.O.N."
                );

                contenido.setCenter(new PanelInventario());
                return;

            case "Finanzas":

                tituloModulo.setText("Finanzas");

                subtituloModulo.setText(
                        "Administración de presupuestos y pagos de P.I.S.T.O.N."
                );

                contenido.setCenter(new PanelFinanzas());
                return;

            case "Diagnósticos":

                tituloModulo.setText("Diagnósticos");

                subtituloModulo.setText(
                        "Inspección y diagnóstico de vehículos."
                );

                contenido.setCenter(new PanelDiagnosticos());
                return;
                
                case "Servicios":

    tituloModulo.setText("Catálogo de Servicios");

    subtituloModulo.setText(
            "Administración de servicios y tarifas del taller."
    );

    contenido.setCenter(new PanelServicios());
    return;
        }

        contenido.setCenter(panel);
    }
}