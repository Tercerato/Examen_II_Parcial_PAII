/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;

import hn.edu.piston.modelo.Usuario;
import java.util.List;
/**
 *
 * @author Alexander
 */


public interface UsuarioDAO {

    Usuario autenticar(String usuario, String contrasena);

    List<Usuario> listar();

    boolean registrar(Usuario usuario);

    boolean actualizar(Usuario usuario);

    boolean cambiarEstado(int idUsuario, boolean estado);
}
