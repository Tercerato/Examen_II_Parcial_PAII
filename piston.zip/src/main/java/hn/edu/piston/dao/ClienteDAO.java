/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.Cliente;
import java.util.List;
/**
 *
 * @author Alexander
 */
public interface ClienteDAO {

    List<Cliente> listar();

    Cliente buscarPorId(int idCliente);

    boolean insertar(Cliente cliente);

    boolean actualizar(Cliente cliente);

    boolean eliminar(int idCliente);
}
