/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.Mecanico;
import java.util.List;
/**
 *
 * @author Alexander
 */
public interface MecanicoDAO {

    List<Mecanico> listar();

    Mecanico buscarPorId(int idMecanico);

    boolean insertar(Mecanico mecanico);

    boolean actualizar(Mecanico mecanico);

    boolean eliminar(int idMecanico);

    boolean activar(int idMecanico);
}