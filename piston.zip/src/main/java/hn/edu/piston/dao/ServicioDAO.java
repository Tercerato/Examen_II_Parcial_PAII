/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.Servicio;
import java.util.List;

/**
 *
 * @author Alexander
 */
public interface ServicioDAO {

    List<Servicio> listar();

    Servicio buscarPorId(int id);

    boolean insertar(Servicio servicio);

    boolean actualizar(Servicio servicio);

    boolean cambiarEstado(int id, String estado);
}