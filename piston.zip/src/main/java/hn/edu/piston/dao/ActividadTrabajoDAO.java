/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.ActividadTrabajo;
import java.util.List;
/**
 *
 * @author Alexander
 */
public interface ActividadTrabajoDAO {

    List<ActividadTrabajo> listarPorOrden(int idOrden);

    boolean insertar(ActividadTrabajo actividad);

    boolean actualizarEstado(int idActividad, String estado);
}