/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.Repuesto;
import java.util.List;
/**
 *
 * @author Alexander
 */
public interface RepuestoDAO {

    List<Repuesto> listar();

    Repuesto buscarPorId(int idRepuesto);

    boolean insertar(Repuesto repuesto);

    boolean actualizar(Repuesto repuesto);

    boolean eliminar(int idRepuesto);

    boolean activar(int idRepuesto);
}
