/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.OrdenTrabajo;
import java.util.List;
/**
 *
 * @author Alexander
 */
public interface OrdenTrabajoDAO {

    List<OrdenTrabajo> listar();

    OrdenTrabajo buscarPorId(int id);

    boolean insertar(OrdenTrabajo orden);

    boolean actualizar(OrdenTrabajo orden);

    boolean cambiarEstado(int id, String estado);
}