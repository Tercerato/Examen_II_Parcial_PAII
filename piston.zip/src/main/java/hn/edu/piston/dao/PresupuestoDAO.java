/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.Presupuesto;
import java.util.List;

/**
 *
 * @author Alexander
 */
public interface PresupuestoDAO {

    List<Presupuesto> listar();

    Presupuesto buscarPorId(int idPresupuesto);

    Presupuesto buscarPorOrden(int idOrden);

    boolean insertar(Presupuesto presupuesto);

    boolean actualizarEstado(int idPresupuesto, String estado);
}