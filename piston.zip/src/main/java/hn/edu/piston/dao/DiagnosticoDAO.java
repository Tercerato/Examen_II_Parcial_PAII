/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.Diagnostico;
import java.util.List;
/**
 *
 * @author Alexander
 */
public interface DiagnosticoDAO {

    List<Diagnostico> listar();

    List<Diagnostico> listarPorOrden(int idOrden);

    boolean insertar(Diagnostico diagnostico);
}
