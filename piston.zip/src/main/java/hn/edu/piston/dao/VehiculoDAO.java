/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao;
import hn.edu.piston.modelo.Vehiculo;
import java.util.List;
/**
 *
 * @author Alexander
 */
public interface VehiculoDAO {

    List<Vehiculo> listar();

    Vehiculo buscarPorId(int idVehiculo);

    boolean insertar(Vehiculo vehiculo);

    boolean actualizar(Vehiculo vehiculo);

    boolean eliminar(int idVehiculo);

    boolean activar(int idVehiculo);
}
