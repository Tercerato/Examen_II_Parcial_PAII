/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.modelo;
import java.time.LocalDateTime;
/**
 *
 * @author Alexander
 */
public class Presupuesto {

    private int idPresupuesto;
    private int idOrden;
    private double horasManoObra;
    private double costoHora;
    private double subtotalServicios;
    private double subtotalRepuestos;
    private double descuento;
    private double porcentajeImpuesto;
    private double impuesto;
    private double total;
    private String estado;
    private LocalDateTime fecha;

    public Presupuesto() {
    }

    public int getIdPresupuesto() {
        return idPresupuesto;
    }

    public void setIdPresupuesto(int idPresupuesto) {
        this.idPresupuesto = idPresupuesto;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public double getHorasManoObra() {
        return horasManoObra;
    }

    public void setHorasManoObra(double horasManoObra) {
        this.horasManoObra = horasManoObra;
    }

    public double getCostoHora() {
        return costoHora;
    }

    public void setCostoHora(double costoHora) {
        this.costoHora = costoHora;
    }

    public double getSubtotalServicios() {
        return subtotalServicios;
    }

    public void setSubtotalServicios(double subtotalServicios) {
        this.subtotalServicios = subtotalServicios;
    }

    public double getSubtotalRepuestos() {
        return subtotalRepuestos;
    }

    public void setSubtotalRepuestos(double subtotalRepuestos) {
        this.subtotalRepuestos = subtotalRepuestos;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getPorcentajeImpuesto() {
        return porcentajeImpuesto;
    }

    public void setPorcentajeImpuesto(double porcentajeImpuesto) {
        this.porcentajeImpuesto = porcentajeImpuesto;
    }

    public double getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(double impuesto) {
        this.impuesto = impuesto;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }
}
