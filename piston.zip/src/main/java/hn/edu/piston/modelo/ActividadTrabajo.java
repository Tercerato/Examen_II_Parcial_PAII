/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.modelo;

/**
 *
 * @author Alexander
 */
public class ActividadTrabajo {

    private int idActividad;
    private int idOrden;
    private int idMecanico;
    private String descripcion;
    private String estado;  
    private String nombreMecanico;

    public ActividadTrabajo() {
    }

    public ActividadTrabajo(int idActividad, int idOrden,
            int idMecanico, String descripcion, String estado) {

        this.idActividad = idActividad;
        this.idOrden = idOrden;
        this.idMecanico = idMecanico;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    public int getIdActividad() {
        return idActividad;
    }

    public void setIdActividad(int idActividad) {
        this.idActividad = idActividad;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getIdMecanico() {
        return idMecanico;
    }

    public void setIdMecanico(int idMecanico) {
        this.idMecanico = idMecanico;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public String getNombreMecanico() {
    return nombreMecanico;
}

public void setNombreMecanico(String nombreMecanico) {
    this.nombreMecanico = nombreMecanico;
}
}