/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.ServicioDAO;
import hn.edu.piston.daoimpl.ServicioDAOImpl;
import hn.edu.piston.modelo.Servicio;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
/**
 *
 * @author Alexander
 */
public class PanelServicios extends BorderPane {

    private final ServicioDAO servicioDAO = new ServicioDAOImpl();

    private TableView<Servicio> tabla = new TableView<>();

    private TextField txtCodigo = new TextField();
    private TextField txtNombre = new TextField();
    private TextField txtDescripcion = new TextField();
    private TextField txtCosto = new TextField();
    private TextField txtTiempo = new TextField();

    private ComboBox<Integer> cmbNivel = new ComboBox<>();
    private ComboBox<String> cmbEstado = new ComboBox<>();

    private int idSeleccionado = 0;

    public PanelServicios() {
        construirInterfaz();
        configurarTabla();
        cargarServicios();
    }

    private void construirInterfaz() {

        setPadding(new Insets(20));
        setBackground(new Background(new BackgroundFill(
                Color.web("#08080b"), CornerRadii.EMPTY, Insets.EMPTY)));

        Label titulo = new Label("Catálogo de Servicios");
        titulo.getStyleClass().add("titulo-principal");

        Label subtitulo = new Label(
                "Administración de servicios del taller");
        subtitulo.getStyleClass().add("subtitulo");

        VBox encabezado = new VBox(5, titulo, subtitulo);

        txtCodigo.setPromptText("Código");
        txtNombre.setPromptText("Nombre del servicio");
        txtDescripcion.setPromptText("Descripción");
        txtCosto.setPromptText("Costo mano de obra");
        txtTiempo.setPromptText("Tiempo estimado (min)");

        cmbNivel.setPromptText("Nivel de complejidad");
        cmbNivel.setItems(FXCollections.observableArrayList(
                1, 2, 3, 4, 5));

        cmbEstado.setItems(FXCollections.observableArrayList(
                "Activo", "Inactivo"));
        cmbEstado.setValue("Activo");

        GridPane formulario = new GridPane();
        formulario.setHgap(12);
        formulario.setVgap(12);

        formulario.add(txtCodigo, 0, 0);
        formulario.add(txtNombre, 1, 0);
        formulario.add(txtDescripcion, 2, 0);
        formulario.add(cmbNivel, 0, 1);
        formulario.add(txtCosto, 1, 1);
        formulario.add(txtTiempo, 2, 1);
        formulario.add(cmbEstado, 0, 2);

        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(33.33);

        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(33.33);

        ColumnConstraints col3 = new ColumnConstraints();
        col3.setPercentWidth(33.33);

        formulario.getColumnConstraints().addAll(
                col1, col2, col3);

        for (var nodo : formulario.getChildren()) {
            if (nodo instanceof TextField campo) {
                campo.getStyleClass().add("campo-texto");
            }
            if (nodo instanceof ComboBox combo) {
                combo.getStyleClass().add("campo-texto");
            }
        }

        Button btnRegistrar = new Button("Registrar");
        Button btnEditar = new Button("Editar");
        Button btnEstado = new Button("Activar / Desactivar");
        Button btnActualizar = new Button("Actualizar");
        Button btnLimpiar = new Button("Limpiar");

        btnRegistrar.getStyleClass().add("boton-primario");
        btnEditar.getStyleClass().add("boton-secundario");
        btnEstado.getStyleClass().add("boton-secundario");
        btnActualizar.getStyleClass().add("boton-secundario");
        btnLimpiar.getStyleClass().add("boton-secundario");

        btnRegistrar.setOnAction(e -> registrar());
        btnEditar.setOnAction(e -> editar());
        btnEstado.setOnAction(e -> cambiarEstado());
        btnActualizar.setOnAction(e -> cargarServicios());
        btnLimpiar.setOnAction(e -> limpiarFormulario());

        HBox botones = new HBox(10,
                btnRegistrar, btnEditar,
                btnEstado, btnActualizar, btnLimpiar);

        VBox formularioCompleto = new VBox(15,
                encabezado, formulario, botones);
        formularioCompleto.setPadding(new Insets(0, 0, 20, 0));

        setTop(formularioCompleto);

        tabla.getStyleClass().add("tabla-piston-clara");

        VBox contenedorTabla = new VBox(10, tabla);
        VBox.setVgrow(tabla, Priority.ALWAYS);

        setCenter(contenedorTabla);
    }

    private void configurarTabla() {

        TableColumn<Servicio, Integer> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                new PropertyValueFactory<>("idServicio"));

        TableColumn<Servicio, String> colCodigo =
                new TableColumn<>("Código");

        colCodigo.setCellValueFactory(
                new PropertyValueFactory<>("codigo"));

        TableColumn<Servicio, String> colNombre =
                new TableColumn<>("Servicio");

        colNombre.setCellValueFactory(
                new PropertyValueFactory<>("nombre"));

        TableColumn<Servicio, Integer> colNivel =
                new TableColumn<>("Nivel");

        colNivel.setCellValueFactory(
                new PropertyValueFactory<>("nivelComplejidad"));

        TableColumn<Servicio, Double> colCosto =
                new TableColumn<>("Mano de obra");

        colCosto.setCellValueFactory(
                new PropertyValueFactory<>("costoManoObra"));

        TableColumn<Servicio, Integer> colTiempo =
                new TableColumn<>("Tiempo (min)");

        colTiempo.setCellValueFactory(
                new PropertyValueFactory<>("tiempoEstimado"));

        TableColumn<Servicio, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(
                new PropertyValueFactory<>("estado"));

        tabla.getColumns().addAll(
                colId, colCodigo, colNombre,
                colNivel, colCosto, colTiempo, colEstado);

        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        tabla.setPlaceholder(
                new Label("No hay servicios registrados"));

        tabla.getSelectionModel()
                .selectedItemProperty()
                .addListener((obs, anterior, seleccionado) -> {

                    if (seleccionado != null) {
                        idSeleccionado =
                                seleccionado.getIdServicio();

                        txtCodigo.setText(
                                seleccionado.getCodigo());

                        txtNombre.setText(
                                seleccionado.getNombre());

                        txtDescripcion.setText(
                                seleccionado.getDescripcion());

                        cmbNivel.setValue(
                                seleccionado.getNivelComplejidad());

                        txtCosto.setText(
                                String.valueOf(
                                        seleccionado.getCostoManoObra()));

                        txtTiempo.setText(
                                String.valueOf(
                                        seleccionado.getTiempoEstimado()));

                        cmbEstado.setValue(
                                seleccionado.getEstado());
                    }
                });
    }

    private void cargarServicios() {

        tabla.setItems(
                FXCollections.observableArrayList(
                        servicioDAO.listar()));
    }

    private void registrar() {

        if (!validarFormulario()) {
            return;
        }

        Servicio servicio = obtenerDatosFormulario();

        if (servicioDAO.insertar(servicio)) {
            mostrarMensaje("Servicio registrado correctamente");
            cargarServicios();
            limpiarFormulario();
        } else {
            mostrarError("No se pudo registrar el servicio");
        }
    }

    private void editar() {

        if (idSeleccionado == 0) {
            mostrarError("Selecciona un servicio");
            return;
        }

        if (!validarFormulario()) {
            return;
        }

        Servicio servicio = obtenerDatosFormulario();
        servicio.setIdServicio(idSeleccionado);

        if (servicioDAO.actualizar(servicio)) {
            mostrarMensaje("Servicio actualizado correctamente");
            cargarServicios();
            limpiarFormulario();
        } else {
            mostrarError("No se pudo actualizar el servicio");
        }
    }

    private void cambiarEstado() {

        Servicio seleccionado =
                tabla.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {
            mostrarError("Selecciona un servicio");
            return;
        }

        String nuevoEstado =
                seleccionado.getEstado().equalsIgnoreCase("Activo")
                ? "Inactivo"
                : "Activo";

        if (servicioDAO.cambiarEstado(
                seleccionado.getIdServicio(), nuevoEstado)) {

            mostrarMensaje("Estado actualizado correctamente");
            cargarServicios();
            limpiarFormulario();

        } else {
            mostrarError("No se pudo cambiar el estado");
        }
    }

    private Servicio obtenerDatosFormulario() {

        Servicio servicio = new Servicio();

        servicio.setCodigo(txtCodigo.getText().trim());
        servicio.setNombre(txtNombre.getText().trim());
        servicio.setDescripcion(txtDescripcion.getText().trim());
        servicio.setNivelComplejidad(cmbNivel.getValue());
        servicio.setCostoManoObra(
                Double.parseDouble(txtCosto.getText().trim()));
        servicio.setTiempoEstimado(
                Integer.parseInt(txtTiempo.getText().trim()));
        servicio.setEstado(cmbEstado.getValue());

        return servicio;
    }

    private boolean validarFormulario() {

        if (txtCodigo.getText().trim().isEmpty()
                || txtNombre.getText().trim().isEmpty()
                || txtDescripcion.getText().trim().isEmpty()
                || cmbNivel.getValue() == null
                || txtCosto.getText().trim().isEmpty()
                || txtTiempo.getText().trim().isEmpty()
                || cmbEstado.getValue() == null) {

            mostrarError("Completa todos los campos");
            return false;
        }

        try {

            double costo =
                    Double.parseDouble(txtCosto.getText().trim());

            int tiempo =
                    Integer.parseInt(txtTiempo.getText().trim());

            if (costo < 0 || tiempo <= 0) {
                mostrarError(
                        "El costo no puede ser negativo "
                        + "y el tiempo debe ser mayor que cero");
                return false;
            }

        } catch (NumberFormatException e) {
            mostrarError(
                    "Costo y tiempo deben ser valores numéricos");
            return false;
        }

        return true;
    }

    private void limpiarFormulario() {

        txtCodigo.clear();
        txtNombre.clear();
        txtDescripcion.clear();
        txtCosto.clear();
        txtTiempo.clear();

        cmbNivel.getSelectionModel().clearSelection();
        cmbEstado.setValue("Activo");

        idSeleccionado = 0;
        tabla.getSelectionModel().clearSelection();
    }

    private void mostrarMensaje(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void mostrarError(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.WARNING);
        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText("Atención");
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}