/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.MecanicoDAO;
import hn.edu.piston.daoimpl.MecanicoDAOImpl;
import hn.edu.piston.modelo.Mecanico;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
/**
 *
 * @author Alexander
 */
public class PanelMecanicos extends BorderPane {

    private final MecanicoDAO mecanicoDAO = new MecanicoDAOImpl();

    private final TableView<Mecanico> tabla = new TableView<>();
    private final ObservableList<Mecanico> lista =
            FXCollections.observableArrayList();

    private final TextField txtBuscar = new TextField();

    private final Button btnRegistrar = new Button("Registrar mecánico");
    private final Button btnEstado = new Button("Activar / Desactivar");
    private final Button btnActualizar = new Button("Actualizar");

public PanelMecanicos() {
    construirInterfaz();
    configurarTabla();
    configurarEstiloEncabezados();
    cargarMecanicos();
}

    private void construirInterfaz() {

        setPadding(new Insets(20));
        setStyle("-fx-background-color: #111318;");

        Label titulo = new Label("Gestión de mecánicos");
        titulo.setStyle(
                "-fx-font-size: 24px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: white;"
        );

        Label subtitulo = new Label(
                "Administración del personal técnico del taller"
        );
        subtitulo.setStyle("-fx-text-fill: #A0A0A0;");

        VBox encabezado = new VBox(5, titulo, subtitulo);

        txtBuscar.setPromptText("Buscar por nombre o especialidad...");
        txtBuscar.setPrefWidth(280);
        txtBuscar.setStyle(
                "-fx-background-color: #202127;"
                + "-fx-text-fill: white;"
                + "-fx-prompt-text-fill: #777777;"
                + "-fx-background-radius: 6;"
                + "-fx-border-color: #34343A;"
                + "-fx-border-radius: 6;"
        );

        estilizarBoton(btnRegistrar, true);
        estilizarBoton(btnEstado, false);
        estilizarBoton(btnActualizar, false);

        HBox barra = new HBox(10,
                txtBuscar, btnRegistrar, btnEstado, btnActualizar);
        barra.setPadding(new Insets(20, 0, 15, 0));
        barra.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        VBox superior = new VBox(encabezado, barra);
        setTop(superior);

        tabla.setItems(lista);
        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

tabla.setStyle(
        "-fx-background-color: #202127;"
        + "-fx-control-inner-background: #202127;"
        + "-fx-text-background-color: white;"
        + "-fx-table-cell-border-color: #DCDCDC;"
);
        setCenter(tabla);

        btnRegistrar.setOnAction(e -> registrarMecanico());
        btnEstado.setOnAction(e -> cambiarEstado());
        btnActualizar.setOnAction(e -> cargarMecanicos());

        txtBuscar.textProperty().addListener(
                (observable, anterior, nuevo) -> buscarMecanicos(nuevo)
        );

        tabla.setRowFactory(tv -> {
            TableRow<Mecanico> fila = new TableRow<>();

            fila.setOnMouseClicked(evento -> {
                if (evento.getClickCount() == 2
                        && !fila.isEmpty()) {
                    editarMecanico(fila.getItem());
                }
            });

            return fila;
        });
    }

    private void configurarTabla() {

        TableColumn<Mecanico, Number> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                datos -> new javafx.beans.property.SimpleIntegerProperty(
                        datos.getValue().getIdMecanico()
                )
        );

        TableColumn<Mecanico, String> colNombre =
                new TableColumn<>("Nombre");

        colNombre.setCellValueFactory(
                datos -> new javafx.beans.property.SimpleStringProperty(
                        datos.getValue().getNombre()
                )
        );

        TableColumn<Mecanico, String> colEspecialidad =
                new TableColumn<>("Especialidad");

        colEspecialidad.setCellValueFactory(
                datos -> new javafx.beans.property.SimpleStringProperty(
                        datos.getValue().getEspecialidad()
                )
        );

        TableColumn<Mecanico, String> colTelefono =
                new TableColumn<>("Teléfono");

        colTelefono.setCellValueFactory(
                datos -> new javafx.beans.property.SimpleStringProperty(
                        datos.getValue().getTelefono()
                )
        );

        TableColumn<Mecanico, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(
                datos -> new javafx.beans.property.SimpleStringProperty(
                        datos.getValue().isEstado()
                                ? "Activo" : "Inactivo"
                )
        );

        tabla.getColumns().addAll(
                colId, colNombre, colEspecialidad,
                colTelefono, colEstado
        );
    }

    private void cargarMecanicos() {
        lista.setAll(mecanicoDAO.listar());
    }

    private void buscarMecanicos(String texto) {

        if (texto == null || texto.trim().isEmpty()) {
            cargarMecanicos();
            return;
        }

        String busqueda = texto.toLowerCase().trim();

        ObservableList<Mecanico> filtrados =
                FXCollections.observableArrayList();

        for (Mecanico m : mecanicoDAO.listar()) {

            if (m.getNombre().toLowerCase().contains(busqueda)
                    || m.getEspecialidad().toLowerCase().contains(busqueda)) {

                filtrados.add(m);
            }
        }

        lista.setAll(filtrados);
    }

    private void registrarMecanico() {

        Dialog<Mecanico> dialogo = crearFormulario(null);

        dialogo.showAndWait().ifPresent(mecanico -> {

            if (mecanicoDAO.insertar(mecanico)) {
                cargarMecanicos();
                mostrarMensaje("Mecánico registrado correctamente.");
            } else {
                mostrarError("No se pudo registrar el mecánico.");
            }
        });
    }

    private void editarMecanico(Mecanico seleccionado) {

        Dialog<Mecanico> dialogo = crearFormulario(seleccionado);

        dialogo.showAndWait().ifPresent(mecanico -> {

            mecanico.setIdMecanico(seleccionado.getIdMecanico());

            if (mecanicoDAO.actualizar(mecanico)) {
                cargarMecanicos();
                mostrarMensaje("Mecánico actualizado correctamente.");
            } else {
                mostrarError("No se pudo actualizar el mecánico.");
            }
        });
    }

    private Dialog<Mecanico> crearFormulario(Mecanico existente) {

        Dialog<Mecanico> dialogo = new Dialog<>();
        dialogo.setTitle(
                existente == null
                        ? "Registrar mecánico"
                        : "Editar mecánico"
        );

        ButtonType guardar = new ButtonType(
                "Guardar", ButtonBar.ButtonData.OK_DONE
        );

        dialogo.getDialogPane().getButtonTypes().addAll(
                guardar, ButtonType.CANCEL
        );

        TextField txtNombre = new TextField();
        TextField txtEspecialidad = new TextField();
        TextField txtTelefono = new TextField();

        txtNombre.setPromptText("Nombre completo");
        txtEspecialidad.setPromptText("Especialidad");
        txtTelefono.setPromptText("Teléfono");

        if (existente != null) {
            txtNombre.setText(existente.getNombre());
            txtEspecialidad.setText(existente.getEspecialidad());
            txtTelefono.setText(existente.getTelefono());
        }

        VBox contenido = new VBox(12,
                new Label("Nombre:"), txtNombre,
                new Label("Especialidad:"), txtEspecialidad,
                new Label("Teléfono:"), txtTelefono
        );

        contenido.setPadding(new Insets(20));
        dialogo.getDialogPane().setContent(contenido);

        dialogo.setResultConverter(boton -> {

            if (boton == guardar) {

                if (txtNombre.getText().trim().isEmpty()
                        || txtEspecialidad.getText().trim().isEmpty()) {

                    mostrarError(
                            "Nombre y especialidad son obligatorios."
                    );
                    return null;
                }

                Mecanico m = new Mecanico();

                m.setNombre(txtNombre.getText().trim());
                m.setEspecialidad(
                        txtEspecialidad.getText().trim()
                );
                m.setTelefono(txtTelefono.getText().trim());

                return m;
            }

            return null;
        });

        return dialogo;
    }

    private void cambiarEstado() {

        Mecanico seleccionado =
                tabla.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {
            mostrarError("Selecciona un mecánico de la tabla.");
            return;
        }

        boolean resultado;

        if (seleccionado.isEstado()) {
            resultado = mecanicoDAO.eliminar(
                    seleccionado.getIdMecanico()
            );
        } else {
            resultado = mecanicoDAO.activar(
                    seleccionado.getIdMecanico()
            );
        }

        if (resultado) {
            cargarMecanicos();
            mostrarMensaje("Estado del mecánico actualizado.");
        } else {
            mostrarError("No se pudo cambiar el estado.");
        }
    }

    private void mostrarMensaje(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void mostrarError(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText("Atención");
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void estilizarBoton(Button boton, boolean principal) {

        String color = principal ? "#E50914" : "#292A31";

        boton.setStyle(
                "-fx-background-color: " + color + ";"
                + "-fx-text-fill: white;"
                + "-fx-font-weight: bold;"
                + "-fx-background-radius: 6;"
                + "-fx-padding: 10 15 10 15;"
        );
    }
    
    private void configurarEstiloEncabezados() {

    tabla.skinProperty().addListener((observable, anterior, nuevo) -> {

        javafx.application.Platform.runLater(() -> {

            tabla.lookupAll(".column-header").forEach(nodo -> {

                nodo.setStyle(
                        "-fx-background-color: #DCDCDC;"
                        + "-fx-border-color: #B5B5B5;"
                        + "-fx-border-width: 0 1 1 0;"
                );

            });

            tabla.lookupAll(".column-header .label").forEach(nodo -> {

                nodo.setStyle(
                        "-fx-text-fill: black;"
                        + "-fx-font-weight: bold;"
                        + "-fx-alignment: CENTER;"
                );

            });

            tabla.lookupAll(".filler").forEach(nodo -> {

                nodo.setStyle("-fx-background-color: #DCDCDC;");

            });

        });

    });
}
}
