/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.OrdenTrabajoDAO;
import hn.edu.piston.dao.DiagnosticoDAO;
import hn.edu.piston.daoimpl.OrdenTrabajoDAOImpl;
import hn.edu.piston.daoimpl.DiagnosticoDAOImpl;
import hn.edu.piston.modelo.OrdenTrabajo;
import hn.edu.piston.modelo.Diagnostico;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class PanelDiagnosticos extends BorderPane {

    private final OrdenTrabajoDAO ordenDAO =
            new OrdenTrabajoDAOImpl();

    private final DiagnosticoDAO diagnosticoDAO =
            new DiagnosticoDAOImpl();

    private final TableView<OrdenTrabajo> tabla =
            new TableView<>();

    private final ObservableList<OrdenTrabajo> ordenes =
            FXCollections.observableArrayList();

    private final TextField txtBuscar = new TextField();

    public PanelDiagnosticos() {

        setPadding(new Insets(20));

        crearTabla();
        crearBarraSuperior();
        cargarOrdenes();
    }

    private void crearTabla() {

        TableColumn<OrdenTrabajo, Integer> colOrden =
                new TableColumn<>("Orden");

        colOrden.setCellValueFactory(
                new PropertyValueFactory<>("idOrden"));

        TableColumn<OrdenTrabajo, String> colCliente =
                new TableColumn<>("Cliente");

        colCliente.setCellValueFactory(
                new PropertyValueFactory<>("cliente"));

        TableColumn<OrdenTrabajo, String> colPlaca =
                new TableColumn<>("Placa");

        colPlaca.setCellValueFactory(
                new PropertyValueFactory<>("placa"));

        TableColumn<OrdenTrabajo, String> colVehiculo =
                new TableColumn<>("Vehículo");

        colVehiculo.setCellValueFactory(
                new PropertyValueFactory<>("marcaModelo"));

        TableColumn<OrdenTrabajo, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(
                new PropertyValueFactory<>("estado"));

        tabla.getColumns().addAll(
                colOrden,
                colCliente,
                colPlaca,
                colVehiculo,
                colEstado
        );

        tabla.setItems(ordenes);

        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS
        );

        tabla.getStyleClass().add("tabla-piston-clara");

        setCenter(tabla);
    }

    private void crearBarraSuperior() {

        txtBuscar.setPromptText(
                "Buscar por orden, placa o cliente..."
        );

        txtBuscar.setPrefWidth(300);

        Button btnRegistrar =
                new Button("Registrar diagnóstico");

        Button btnHistorial =
                new Button("Ver diagnósticos");

        Button btnActualizar =
                new Button("Actualizar");

btnRegistrar.getStyleClass().add("boton-primario");
btnHistorial.getStyleClass().add("boton-secundario");
btnActualizar.getStyleClass().add("boton-secundario");

        btnRegistrar.setOnAction(
                e -> registrarDiagnostico()
        );

        btnHistorial.setOnAction(
                e -> verDiagnosticos()
        );

        btnActualizar.setOnAction(
                e -> cargarOrdenes()
        );

        txtBuscar.textProperty().addListener(
                (obs, anterior, nuevo) -> filtrarOrdenes(nuevo)
        );

        HBox barra = new HBox(
                10,
                txtBuscar,
                btnRegistrar,
                btnHistorial,
                btnActualizar
        );

        barra.setPadding(new Insets(0, 0, 15, 0));

        setTop(barra);
    }

    private void cargarOrdenes() {

        ordenes.clear();

        List<OrdenTrabajo> lista = ordenDAO.listar();

        if (lista != null) {
            ordenes.addAll(lista);
        }
    }

    private void filtrarOrdenes(String texto) {

        ordenes.clear();

        List<OrdenTrabajo> lista = ordenDAO.listar();

        if (lista == null) {
            return;
        }

        if (texto == null || texto.isBlank()) {
            ordenes.addAll(lista);
            return;
        }

        String filtro = texto.toLowerCase();

        for (OrdenTrabajo orden : lista) {

            String id = String.valueOf(orden.getIdOrden());
            String placa = orden.getPlaca() == null
                    ? "" : orden.getPlaca().toLowerCase();

            String cliente = orden.getCliente() == null
                    ? "" : orden.getCliente().toLowerCase();

            if (id.contains(filtro)
                    || placa.contains(filtro)
                    || cliente.contains(filtro)) {

                ordenes.add(orden);
            }
        }
    }

    private void registrarDiagnostico() {

        OrdenTrabajo orden =
                tabla.getSelectionModel().getSelectedItem();

        if (orden == null) {

            mostrarAlerta(
                    "Información",
                    "Seleccione una orden de trabajo."
            );

            return;
        }

        TextArea txtDescripcion = new TextArea();
        TextArea txtEvidencia = new TextArea();

        txtDescripcion.setPromptText(
                "Describa los problemas encontrados..."
        );

        txtEvidencia.setPromptText(
                "Observaciones o evidencia del diagnóstico..."
        );

        txtDescripcion.setPrefRowCount(5);
        txtEvidencia.setPrefRowCount(3);

        VBox contenido = new VBox(
                10,
                new Label("Orden #" + orden.getIdOrden()),
                new Label("Diagnóstico"),
                txtDescripcion,
                new Label("Evidencia"),
                txtEvidencia
        );

        contenido.setPadding(new Insets(10));

        Dialog<ButtonType> dialogo = new Dialog<>();

        dialogo.setTitle("Registrar diagnóstico");
        dialogo.setHeaderText(
                "Diagnóstico de orden #" + orden.getIdOrden()
        );

        dialogo.getDialogPane().setContent(contenido);

        dialogo.getDialogPane().getButtonTypes().addAll(
                ButtonType.OK,
                ButtonType.CANCEL
        );

        dialogo.showAndWait().ifPresent(resultado -> {

            if (resultado != ButtonType.OK) {
                return;
            }

            String descripcion =
                    txtDescripcion.getText().trim();

            String evidencia =
                    txtEvidencia.getText().trim();

            if (descripcion.isEmpty()) {

                mostrarAlerta(
                        "Error",
                        "Debe ingresar la descripción del diagnóstico."
                );

                return;
            }

            Diagnostico diagnostico = new Diagnostico();

            diagnostico.setIdOrden(orden.getIdOrden());
            diagnostico.setDescripcion(descripcion);

            diagnostico.setEvidencia(
                    evidencia.isEmpty() ? null : evidencia
            );

            if (diagnosticoDAO.insertar(diagnostico)) {

                mostrarAlerta(
                        "Éxito",
                        "Diagnóstico registrado correctamente."
                );

            } else {

                mostrarAlerta(
                        "Error",
                        "No se pudo registrar el diagnóstico."
                );
            }
        });
    }

    private void verDiagnosticos() {

        OrdenTrabajo orden =
                tabla.getSelectionModel().getSelectedItem();

        if (orden == null) {

            mostrarAlerta(
                    "Información",
                    "Seleccione una orden de trabajo."
            );

            return;
        }

        List<Diagnostico> lista =
                diagnosticoDAO.listarPorOrden(
                        orden.getIdOrden()
                );

        if (lista == null || lista.isEmpty()) {

            mostrarAlerta(
                    "Información",
                    "Esta orden todavía no tiene diagnósticos."
            );

            return;
        }

        StringBuilder historial = new StringBuilder();

        for (Diagnostico d : lista) {

            historial.append("Fecha: ")
                    .append(d.getFecha())
                    .append("\n\nDiagnóstico: ")
                    .append(d.getDescripcion())
                    .append("\n\nEvidencia: ")
                    .append(d.getEvidencia() == null
                            ? "Sin evidencia"
                            : d.getEvidencia())
                    .append("\n\n--------------------------\n\n");
        }

        TextArea texto = new TextArea(
                historial.toString()
        );

        texto.setEditable(false);
        texto.setWrapText(true);
        texto.setPrefWidth(600);
        texto.setPrefHeight(400);

        Alert alerta = new Alert(
                Alert.AlertType.INFORMATION
        );

        alerta.setTitle("Historial de diagnósticos");
        alerta.setHeaderText(
                "Orden #" + orden.getIdOrden()
        );

        alerta.getDialogPane().setContent(texto);

        alerta.showAndWait();
    }

    private void mostrarAlerta(
            String titulo,
            String mensaje) {

        Alert alerta = new Alert(
                Alert.AlertType.INFORMATION
        );

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }
}