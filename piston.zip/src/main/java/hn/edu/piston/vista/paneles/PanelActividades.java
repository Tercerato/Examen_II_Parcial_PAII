/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.ActividadTrabajoDAO;
import hn.edu.piston.dao.OrdenTrabajoDAO;
import hn.edu.piston.dao.MecanicoDAO;

import hn.edu.piston.daoimpl.ActividadTrabajoDAOImpl;
import hn.edu.piston.daoimpl.OrdenTrabajoDAOImpl;
import hn.edu.piston.daoimpl.MecanicoDAOImpl;

import hn.edu.piston.modelo.ActividadTrabajo;
import hn.edu.piston.modelo.OrdenTrabajo;
import hn.edu.piston.modelo.Mecanico;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

/**
 *
 * @author Alexander
 */
public class PanelActividades extends BorderPane {

    private final ActividadTrabajoDAO actividadDAO =
            new ActividadTrabajoDAOImpl();

    private final OrdenTrabajoDAO ordenDAO =
            new OrdenTrabajoDAOImpl();

    private final MecanicoDAO mecanicoDAO =
            new MecanicoDAOImpl();

    private final TableView<ActividadTrabajo> tabla =
            new TableView<>();

    private final ObservableList<ActividadTrabajo> lista =
            FXCollections.observableArrayList();

    private final ComboBox<OrdenTrabajo> cmbOrden =
            new ComboBox<>();

    private final ComboBox<Mecanico> cmbMecanico =
            new ComboBox<>();

    private final TextArea txtDescripcion =
            new TextArea();

    private final Button btnRegistrar =
            new Button("Registrar actividad");

    private final Button btnCambiarEstado =
            new Button("Cambiar estado");

    private final Button btnActualizar =
            new Button("Actualizar");

public PanelActividades() {

    setPadding(new Insets(20));
    setStyle("-fx-background-color: #111318;");

    construirInterfaz();
    configurarTabla();
    cargarOrdenes();
    cargarMecanicos();

    configurarSeleccion();
    
    cmbOrden.setOnAction(e -> cargarActividades());
}

    private void construirInterfaz() {

        Label titulo = new Label("Actividades de trabajo");
        titulo.setStyle(
                "-fx-font-size: 24px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: white;"
        );

        Label subtitulo = new Label(
                "Registro y seguimiento de actividades del taller"
        );
        subtitulo.setStyle("-fx-text-fill: #A0A0A0;");

        cmbOrden.setPromptText("Seleccionar orden");
        cmbOrden.setMaxWidth(Double.MAX_VALUE);

        cmbOrden.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(OrdenTrabajo orden, boolean empty) {
                super.updateItem(orden, empty);

                setText(empty || orden == null
                        ? null
                        : "Orden #" + orden.getIdOrden()
                        + " - " + orden.getPlaca());
            }
        });

        cmbOrden.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(OrdenTrabajo orden, boolean empty) {
                super.updateItem(orden, empty);

                setText(empty || orden == null
                        ? "Seleccionar orden"
                        : "Orden #" + orden.getIdOrden()
                        + " - " + orden.getPlaca());
            }
        });

        cmbMecanico.setPromptText("Seleccionar mecánico");
        cmbMecanico.setMaxWidth(Double.MAX_VALUE);

        cmbMecanico.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Mecanico mecanico, boolean empty) {
                super.updateItem(mecanico, empty);

                setText(empty || mecanico == null
                        ? null
                        : mecanico.getNombre());
            }
        });

        cmbMecanico.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Mecanico mecanico, boolean empty) {
                super.updateItem(mecanico, empty);

                setText(empty || mecanico == null
                        ? "Seleccionar mecánico"
                        : mecanico.getNombre());
            }
        });

        txtDescripcion.setPromptText(
                "Describa la actividad que realizará el mecánico..."
        );

        txtDescripcion.setWrapText(true);
        txtDescripcion.setPrefRowCount(3);

        btnRegistrar.getStyleClass().add("boton-primario");
        btnCambiarEstado.getStyleClass().add("boton-secundario");
        btnActualizar.getStyleClass().add("boton-secundario");

        btnRegistrar.setOnAction(e -> registrarActividad());
        btnCambiarEstado.setOnAction(e -> cambiarEstado());
        btnActualizar.setOnAction(e -> cargarActividades());

        VBox formulario = new VBox(
                10,
                new Label("Orden de trabajo"),
                cmbOrden,
                new Label("Mecánico responsable"),
                cmbMecanico,
                new Label("Descripción"),
                txtDescripcion
        );

        formulario.setPadding(new Insets(15, 0, 15, 0));

        HBox botones = new HBox(
                10,
                btnRegistrar,
                btnCambiarEstado,
                btnActualizar
        );

        botones.setAlignment(Pos.CENTER_LEFT);

        VBox superior = new VBox(
                8,
                titulo,
                subtitulo,
                formulario,
                botones
        );

        superior.setPadding(new Insets(0, 0, 15, 0));

        setTop(superior);
        setCenter(tabla);
    }

    private void configurarTabla() {

        TableColumn<ActividadTrabajo, Integer> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                new PropertyValueFactory<>("idActividad"));

        TableColumn<ActividadTrabajo, Integer> colOrden =
                new TableColumn<>("Orden");

        colOrden.setCellValueFactory(
                new PropertyValueFactory<>("idOrden"));

        TableColumn<ActividadTrabajo, String> colMecanico =
        new TableColumn<>("Mecánico");

colMecanico.setCellValueFactory(
        new PropertyValueFactory<>("nombreMecanico"));

        TableColumn<ActividadTrabajo, String> colDescripcion =
                new TableColumn<>("Descripción");

        colDescripcion.setCellValueFactory(
                new PropertyValueFactory<>("descripcion"));

        TableColumn<ActividadTrabajo, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(
                new PropertyValueFactory<>("estado"));

        tabla.getColumns().addAll(
                colId,
                colOrden,
                colMecanico,
                colDescripcion,
                colEstado
        );

        tabla.setItems(lista);

        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS
        );

        tabla.getStyleClass().add("tabla-piston");
    }
    
    
private void configurarSeleccion() {

    tabla.getSelectionModel()
            .selectedItemProperty()
            .addListener((observable, anterior, seleccionada) -> {

        if (seleccionada == null) {
            return;
        }

        txtDescripcion.setText(
                seleccionada.getDescripcion()
        );

        // Seleccionar la orden correspondiente
        cmbOrden.getItems().stream()
                .filter(o -> o.getIdOrden()
                        == seleccionada.getIdOrden())
                .findFirst()
                .ifPresent(cmbOrden::setValue);

        // Seleccionar el mecánico correspondiente
        cmbMecanico.getItems().stream()
                .filter(m -> m.getIdMecanico()
                        == seleccionada.getIdMecanico())
                .findFirst()
                .ifPresent(cmbMecanico::setValue);
    });
}

    private void cargarOrdenes() {

        cmbOrden.setItems(
                FXCollections.observableArrayList(
                        ordenDAO.listar()
                )
        );
    }

    private void cargarMecanicos() {

        cmbMecanico.setItems(
                FXCollections.observableArrayList(
                        mecanicoDAO.listar()
                                .stream()
                                .filter(Mecanico::isEstado)
                                .toList()
                )
        );
    }

    private void cargarActividades() {

        OrdenTrabajo orden = cmbOrden.getValue();

        if (orden == null) {
            lista.clear();
            return;
        }

        lista.setAll(
                actividadDAO.listarPorOrden(
                        orden.getIdOrden()
                )
        );
    }

    private void registrarActividad() {

        OrdenTrabajo orden = cmbOrden.getValue();
        Mecanico mecanico = cmbMecanico.getValue();

        String descripcion =
                txtDescripcion.getText().trim();

        if (orden == null || mecanico == null
                || descripcion.isEmpty()) {

            mostrarMensaje(
                    Alert.AlertType.WARNING,
                    "Complete la orden, el mecánico y la descripción."
            );

            return;
        }

        ActividadTrabajo actividad = new ActividadTrabajo();

        actividad.setIdOrden(orden.getIdOrden());
        actividad.setIdMecanico(mecanico.getIdMecanico());
        actividad.setDescripcion(descripcion);

        if (actividadDAO.insertar(actividad)) {

            txtDescripcion.clear();
            cargarActividades();

            mostrarMensaje(
                    Alert.AlertType.INFORMATION,
                    "Actividad registrada correctamente."
            );

        } else {

            mostrarMensaje(
                    Alert.AlertType.ERROR,
                    "No se pudo registrar la actividad."
            );
        }
    }

   private void cambiarEstado() {

    ActividadTrabajo actividad =
            tabla.getSelectionModel().getSelectedItem();

    if (actividad == null) {
        mostrarMensaje(
                Alert.AlertType.WARNING,
                "Seleccione una actividad."
        );
        return;
    }

    String estadoActual = actividad.getEstado();
    String nuevoEstado;

    switch (estadoActual) {
        case "Pendiente" ->
                nuevoEstado = "En proceso";

        case "En proceso" ->
                nuevoEstado = "Finalizada";

        case "Finalizada" ->
                nuevoEstado = "En proceso";

        default -> {
            mostrarMensaje(
                    Alert.AlertType.WARNING,
                    "Estado desconocido."
            );
            return;
        }
    }

    if (actividadDAO.actualizarEstado(
            actividad.getIdActividad(),
            nuevoEstado)) {

        cargarActividades();

        mostrarMensaje(
                Alert.AlertType.INFORMATION,
                "Estado actualizado a: " + nuevoEstado
        );

    } else {
        mostrarMensaje(
                Alert.AlertType.ERROR,
                "No se pudo cambiar el estado."
        );
    }
}

    private void mostrarMensaje(
            Alert.AlertType tipo,
            String mensaje) {

        Alert alerta = new Alert(tipo);

        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }
}
