/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.OrdenTrabajoDAO;
import hn.edu.piston.dao.PresupuestoDAO;
import hn.edu.piston.daoimpl.OrdenTrabajoDAOImpl;
import hn.edu.piston.daoimpl.PresupuestoDAOImpl;
import hn.edu.piston.modelo.OrdenTrabajo;
import hn.edu.piston.modelo.Presupuesto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class PanelFinanzas extends BorderPane {

    private final PresupuestoDAO presupuestoDAO =
            new PresupuestoDAOImpl();

    private final OrdenTrabajoDAO ordenDAO =
            new OrdenTrabajoDAOImpl();

    private final TableView<Presupuesto> tabla =
            new TableView<>();

    private final ObservableList<Presupuesto> presupuestos =
            FXCollections.observableArrayList();

    public PanelFinanzas() {

        setPadding(new Insets(20));

        crearTabla();
        crearBotones();

        cargarPresupuestos();
    }

    private void crearTabla() {

        TableColumn<Presupuesto, Integer> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                new PropertyValueFactory<>("idPresupuesto"));

        TableColumn<Presupuesto, Integer> colOrden =
                new TableColumn<>("Orden");

        colOrden.setCellValueFactory(
                new PropertyValueFactory<>("idOrden"));

        TableColumn<Presupuesto, Double> colServicios =
                new TableColumn<>("Servicios");

        colServicios.setCellValueFactory(
                new PropertyValueFactory<>("subtotalServicios"));

        TableColumn<Presupuesto, Double> colRepuestos =
                new TableColumn<>("Repuestos");

        colRepuestos.setCellValueFactory(
                new PropertyValueFactory<>("subtotalRepuestos"));

        TableColumn<Presupuesto, Double> colTotal =
                new TableColumn<>("Total");

        colTotal.setCellValueFactory(
                new PropertyValueFactory<>("total"));

        TableColumn<Presupuesto, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(
                new PropertyValueFactory<>("estado"));

        TableColumn<Presupuesto, Object> colFecha =
                new TableColumn<>("Fecha");

        colFecha.setCellValueFactory(
                new PropertyValueFactory<>("fecha"));

        tabla.getColumns().addAll(
                colId,
                colOrden,
                colServicios,
                colRepuestos,
                colTotal,
                colEstado,
                colFecha
        );
        
        tabla.setStyle(
        "-fx-background-color: #111318;" +
        "-fx-control-inner-background: #111318;" +
        "-fx-control-inner-background-alt: #181A20;" +
        "-fx-background-color: #111318;" +
        "-fx-table-cell-border-color: #292B32;" +
        "-fx-text-background-color: white;" +
        "-fx-border-color: #E50914;" +
        "-fx-border-radius: 8;" +
        "-fx-background-radius: 8;"
);
        tabla.setItems(presupuestos);
        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS
        );

        setCenter(tabla);
        
        tabla.setRowFactory(tv -> {

    TableRow<Presupuesto> fila =
            new TableRow<>();

    fila.setStyle(
            "-fx-background-color: #111318;" +
            "-fx-text-fill: white;"
    );

    fila.setOnMouseEntered(e -> {
        if (!fila.isEmpty() && !fila.isSelected()) {
            fila.setStyle(
                    "-fx-background-color: #25272D;"
            );
        }
    });

    fila.setOnMouseExited(e -> {
        if (!fila.isSelected()) {
            fila.setStyle(
                    "-fx-background-color: #111318;"
            );
        }
    });

    return fila;
});
    }

    private void crearBotones() {

        Button btnRegistrar = new Button("Registrar presupuesto");
        Button btnAprobar = new Button("Aprobar");
        Button btnRechazar = new Button("Rechazar");
        Button btnActualizar = new Button("Actualizar");

        btnRegistrar.setOnAction(e -> registrarPresupuesto());
        btnAprobar.setOnAction(e -> cambiarEstado("Aprobado"));
        btnRechazar.setOnAction(e -> cambiarEstado("Rechazado"));
        btnActualizar.setOnAction(e -> cargarPresupuestos());

        HBox botones = new HBox(
                10,
                btnRegistrar,
                btnAprobar,
                btnRechazar,
                btnActualizar
        );
        
        btnRegistrar.getStyleClass().add("boton-principal");
        btnAprobar.getStyleClass().add("boton-principal");
        btnRechazar.getStyleClass().add("boton-principal");
        btnActualizar.getStyleClass().add("boton-principal");

        botones.setPadding(new Insets(0, 0, 15, 0));

        setTop(botones);
        
        estilizarBoton(btnRegistrar);
        estilizarBoton(btnAprobar);
        estilizarBoton(btnRechazar);
        estilizarBoton(btnActualizar);
    }

    private void cargarPresupuestos() {

        presupuestos.clear();

        List<Presupuesto> lista = presupuestoDAO.listar();

        if (lista != null) {
            presupuestos.addAll(lista);
        }
    }

    private void registrarPresupuesto() {

        List<OrdenTrabajo> ordenes = ordenDAO.listar();

        if (ordenes == null || ordenes.isEmpty()) {
            mostrarAlerta(
                    "Información",
                    "No existen órdenes de trabajo."
            );
            return;
        }

        List<Presupuesto> existentes = presupuestoDAO.listar();

        ordenes.removeIf(orden ->
                existentes.stream().anyMatch(
                        p -> p.getIdOrden() == orden.getIdOrden()
                )
        );

        if (ordenes.isEmpty()) {
            mostrarAlerta(
                    "Información",
                    "Todas las órdenes ya tienen presupuesto."
            );
            return;
        }

        ComboBox<OrdenTrabajo> cmbOrden =
                new ComboBox<>();

        cmbOrden.getItems().addAll(ordenes);

        cmbOrden.setCellFactory(list -> new ListCell<>() {
            @Override
            protected void updateItem(OrdenTrabajo orden, boolean empty) {
                super.updateItem(orden, empty);

                if (empty || orden == null) {
                    setText(null);
                } else {
                    setText("Orden #" + orden.getIdOrden()
                            + " - " + orden.getPlaca());
                }
            }
        });

        cmbOrden.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(OrdenTrabajo orden, boolean empty) {
                super.updateItem(orden, empty);

                if (empty || orden == null) {
                    setText("Seleccione una orden");
                } else {
                    setText("Orden #" + orden.getIdOrden()
                            + " - " + orden.getPlaca());
                }
            }
        });

        TextField txtHoras = new TextField();
        TextField txtCostoHora = new TextField();
        TextField txtServicios = new TextField();
        TextField txtRepuestos = new TextField();
        TextField txtDescuento = new TextField();
        TextField txtImpuesto = new TextField();

        txtHoras.setPromptText("Horas");
        txtCostoHora.setPromptText("Costo por hora");
        txtServicios.setPromptText("Subtotal servicios");
        txtRepuestos.setPromptText("Subtotal repuestos");
        txtDescuento.setPromptText("Descuento");
        txtImpuesto.setPromptText("Impuesto %");

        txtDescuento.setText("0");
        txtImpuesto.setText("0");

        VBox contenido = new VBox(
                10,
                new Label("Orden de trabajo"),
                cmbOrden,
                new Label("Horas de mano de obra"),
                txtHoras,
                new Label("Costo por hora"),
                txtCostoHora,
                new Label("Subtotal servicios"),
                txtServicios,
                new Label("Subtotal repuestos"),
                txtRepuestos,
                new Label("Descuento"),
                txtDescuento,
                new Label("Impuesto (%)"),
                txtImpuesto
        );

        contenido.setPadding(new Insets(10));

        Dialog<ButtonType> dialogo = new Dialog<>();

        dialogo.setTitle("Registrar presupuesto");
        dialogo.setHeaderText("Nuevo presupuesto");

        dialogo.getDialogPane().setContent(contenido);

        dialogo.getDialogPane().getButtonTypes().addAll(
                ButtonType.OK,
                ButtonType.CANCEL
        );

        dialogo.setResultConverter(button -> button);

        dialogo.showAndWait().ifPresent(resultado -> {

            if (resultado != ButtonType.OK) {
                return;
            }

            try {

                OrdenTrabajo orden = cmbOrden.getValue();

                if (orden == null) {
                    throw new IllegalArgumentException(
                            "Seleccione una orden."
                    );
                }

                double horas = Double.parseDouble(txtHoras.getText());
                double costoHora = Double.parseDouble(txtCostoHora.getText());
                double servicios = Double.parseDouble(txtServicios.getText());
                double repuestos = Double.parseDouble(txtRepuestos.getText());
                double descuento = Double.parseDouble(txtDescuento.getText());
                double porcentaje = Double.parseDouble(txtImpuesto.getText());

                if (horas < 0 || costoHora < 0 ||
                        servicios < 0 || repuestos < 0 ||
                        descuento < 0 ||
                        porcentaje < 0 || porcentaje > 100) {

                    throw new IllegalArgumentException(
                            "Los valores ingresados no son válidos."
                    );
                }

                double base = servicios + repuestos - descuento;

                if (base < 0) {
                    throw new IllegalArgumentException(
                            "El descuento no puede superar el subtotal."
                    );
                }

                double impuesto = base * porcentaje / 100;
                double total = base + impuesto;

                Presupuesto p = new Presupuesto();

                p.setIdOrden(orden.getIdOrden());
                p.setHorasManoObra(horas);
                p.setCostoHora(costoHora);
                p.setSubtotalServicios(servicios);
                p.setSubtotalRepuestos(repuestos);
                p.setDescuento(descuento);
                p.setPorcentajeImpuesto(porcentaje);
                p.setImpuesto(impuesto);
                p.setTotal(total);
                p.setEstado("Pendiente");

                if (presupuestoDAO.insertar(p)) {

                    mostrarAlerta(
                            "Éxito",
                            "Presupuesto registrado correctamente."
                    );

                    cargarPresupuestos();

                } else {

                    mostrarAlerta(
                            "Error",
                            "No se pudo registrar el presupuesto."
                    );
                }

            } catch (NumberFormatException ex) {

                mostrarAlerta(
                        "Error",
                        "Ingrese valores numéricos válidos."
                );

            } catch (IllegalArgumentException ex) {

                mostrarAlerta(
                        "Error",
                        ex.getMessage()
                );
            }
        });
    }

    private void cambiarEstado(String estado) {

        Presupuesto seleccionado =
                tabla.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {
            mostrarAlerta(
                    "Información",
                    "Seleccione un presupuesto."
            );
            return;
        }

        if (!"Pendiente".equalsIgnoreCase(
                seleccionado.getEstado())) {

            mostrarAlerta(
                    "Información",
                    "Solo se pueden aprobar o rechazar presupuestos pendientes."
            );
            return;
        }

        if (presupuestoDAO.actualizarEstado(
                seleccionado.getIdPresupuesto(),
                estado)) {

            mostrarAlerta(
                    "Éxito",
                    "Presupuesto " + estado.toLowerCase()
                            + " correctamente."
            );

            cargarPresupuestos();

        } else {

            mostrarAlerta(
                    "Error",
                    "No se pudo actualizar el presupuesto."
            );
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }
    
    private void estilizarBoton(Button boton) {

    boton.setStyle(
            "-fx-background-color: #E50914;" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 6;" +
            "-fx-border-radius: 6;" +
            "-fx-padding: 9 15;" +
            "-fx-cursor: hand;"
    );

    boton.setOnMouseEntered(e ->
            boton.setStyle(
                    "-fx-background-color: #B80710;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-weight: bold;" +
                    "-fx-background-radius: 6;" +
                    "-fx-padding: 9 15;" +
                    "-fx-cursor: hand;"
            )
    );

    boton.setOnMouseExited(e ->
            boton.setStyle(
                    "-fx-background-color: #E50914;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-weight: bold;" +
                    "-fx-background-radius: 6;" +
                    "-fx-padding: 9 15;" +
                    "-fx-cursor: hand;"
            )
    );
}
}