/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.RepuestoDAO;
import hn.edu.piston.daoimpl.RepuestoDAOImpl;
import hn.edu.piston.modelo.Repuesto;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import java.util.Optional;
/**
 *
 * @author Alexander
 */


public class PanelInventario extends VBox {

    private final RepuestoDAO repuestoDAO =
            new RepuestoDAOImpl();

    private final ObservableList<Repuesto> listaRepuestos =
            FXCollections.observableArrayList();

    private final TableView<Repuesto> tabla =
            new TableView<>();

    private final TextField txtBuscar = new TextField();

    private final Button btnRegistrar =
            new Button("Registrar repuesto");

    private final Button btnEstado =
            new Button("Activar / Desactivar");

    public PanelInventario() {

        construirInterfaz();
        configurarTabla();
        cargarRepuestos();
        configurarEventos();
    }

    private void construirInterfaz() {

        setSpacing(20);
        setPadding(new Insets(25));

        setStyle("-fx-background-color: #111318;");

        Label titulo = new Label("Inventario");
        titulo.setStyle(
                "-fx-text-fill: white;"
                + "-fx-font-size: 26px;"
                + "-fx-font-weight: bold;"
        );

        Label subtitulo = new Label(
                "Gestión de repuestos y existencias"
        );
        subtitulo.setStyle("-fx-text-fill: #A0A0A0;");

        txtBuscar.setPromptText(
                "Buscar por código o nombre..."
        );

        estilizarBoton(btnRegistrar, true);
        
        estilizarBoton(btnEstado, false);

        HBox barra = new HBox(
                10, txtBuscar, btnRegistrar, btnEstado
        );

        barra.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        HBox.setHgrow(txtBuscar, Priority.ALWAYS);

        VBox encabezado = new VBox(8, titulo, subtitulo);

        getChildren().addAll(encabezado, barra, tabla);
        VBox.setVgrow(tabla, Priority.ALWAYS);
    }

    private void configurarTabla() {

        TableColumn<Repuesto, Integer> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                d -> new javafx.beans.property.SimpleIntegerProperty(
                        d.getValue().getIdRepuesto()).asObject()
        );

        TableColumn<Repuesto, String> colCodigo =
                new TableColumn<>("Código");

        colCodigo.setCellValueFactory(
                d -> new javafx.beans.property.SimpleStringProperty(
                        d.getValue().getCodigo())
        );

        TableColumn<Repuesto, String> colNombre =
                new TableColumn<>("Nombre");

        colNombre.setCellValueFactory(
                d -> new javafx.beans.property.SimpleStringProperty(
                        d.getValue().getNombre())
        );

        TableColumn<Repuesto, String> colDescripcion =
                new TableColumn<>("Descripción");

        colDescripcion.setCellValueFactory(
                d -> new javafx.beans.property.SimpleStringProperty(
                        d.getValue().getDescripcion())
        );

        TableColumn<Repuesto, Integer> colStock =
                new TableColumn<>("Stock");

        colStock.setCellValueFactory(
                d -> new javafx.beans.property.SimpleIntegerProperty(
                        d.getValue().getStock()).asObject()
        );

        TableColumn<Repuesto, Integer> colMinimo =
                new TableColumn<>("Stock mínimo");

        colMinimo.setCellValueFactory(
                d -> new javafx.beans.property.SimpleIntegerProperty(
                        d.getValue().getStockMinimo()).asObject()
        );

        TableColumn<Repuesto, Double> colCosto =
                new TableColumn<>("Costo unitario");

        colCosto.setCellValueFactory(
                d -> new javafx.beans.property.SimpleDoubleProperty(
                        d.getValue().getCostoUnitario()).asObject()
        );

        TableColumn<Repuesto, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(
                d -> new javafx.beans.property.SimpleStringProperty(
                        d.getValue().isEstado()
                                ? "Activo"
                                : "Inactivo")
        );

        tabla.getColumns().addAll(
                colId, colCodigo, colNombre,
                colDescripcion, colStock,
                colMinimo, colCosto, colEstado
        );

        tabla.setItems(listaRepuestos);
        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        tabla.setStyle(
                "-fx-background-color: #202127;"
                + "-fx-control-inner-background: #202127;"
                + "-fx-text-background-color: white;"
                + "-fx-table-cell-border-color: #33343B;"
        );
    }

    private void cargarRepuestos() {

        listaRepuestos.setAll(repuestoDAO.listar());
    }

    private void configurarEventos() {

        txtBuscar.textProperty().addListener(
                (obs, anterior, texto) -> {

            String filtro = texto == null
                    ? ""
                    : texto.toLowerCase().trim();

            listaRepuestos.setAll(
                    repuestoDAO.listar().stream()
                            .filter(r ->
                                    r.getCodigo().toLowerCase()
                                            .contains(filtro)
                                    || r.getNombre().toLowerCase()
                                            .contains(filtro))
                            .toList()
            );
        });

        btnRegistrar.setOnAction(e -> registrarRepuesto());


        btnEstado.setOnAction(e -> cambiarEstado());

        tabla.setRowFactory(tv -> {

            TableRow<Repuesto> fila = new TableRow<>();

            fila.setOnMouseClicked(event -> {

                if (event.getClickCount() == 2
                        && !fila.isEmpty()) {

                    editarRepuesto();
                }
            });

            return fila;
        });
    }

    private void registrarRepuesto() {

        Dialog<Repuesto> dialogo = crearFormulario(null);

        dialogo.showAndWait().ifPresent(repuesto -> {

            if (repuestoDAO.insertar(repuesto)) {

                cargarRepuestos();

                mostrarMensaje(
                        "Repuesto registrado correctamente."
                );

            } else {

                mostrarError(
                        "No se pudo registrar el repuesto."
                );
            }
        });
    }

    private void editarRepuesto() {

        Repuesto seleccionado =
                tabla.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {

            mostrarError("Seleccione un repuesto.");
            return;
        }

        Dialog<Repuesto> dialogo =
                crearFormulario(seleccionado);

        dialogo.showAndWait().ifPresent(repuesto -> {

            if (repuestoDAO.actualizar(repuesto)) {

                cargarRepuestos();

                mostrarMensaje(
                        "Repuesto actualizado correctamente."
                );

            } else {

                mostrarError(
                        "No se pudo actualizar el repuesto."
                );
            }
        });
    }

    private Dialog<Repuesto> crearFormulario(
            Repuesto existente) {

        Dialog<Repuesto> dialogo = new Dialog<>();

        dialogo.setTitle(
                existente == null
                        ? "Registrar repuesto"
                        : "Editar repuesto"
        );

        ButtonType guardar = new ButtonType(
                "Guardar", ButtonBar.ButtonData.OK_DONE
        );

        dialogo.getDialogPane().getButtonTypes().addAll(
                guardar, ButtonType.CANCEL
        );

        TextField txtProveedor = new TextField();
        TextField txtCodigo = new TextField();
        TextField txtNombre = new TextField();
        TextArea txtDescripcion = new TextArea();
        TextField txtStock = new TextField();
        TextField txtMinimo = new TextField();
        TextField txtCosto = new TextField();

        txtProveedor.setPromptText("ID del proveedor");
        txtCodigo.setPromptText("Código");
        txtNombre.setPromptText("Nombre");
        txtDescripcion.setPromptText("Descripción");
        txtStock.setPromptText("Stock");
        txtMinimo.setPromptText("Stock mínimo");
        txtCosto.setPromptText("Costo unitario");

        txtDescripcion.setPrefRowCount(3);
        txtDescripcion.setWrapText(true);

        if (existente != null) {

            txtProveedor.setText(
                    String.valueOf(existente.getIdProveedor())
            );

            txtCodigo.setText(existente.getCodigo());
            txtNombre.setText(existente.getNombre());
            txtDescripcion.setText(existente.getDescripcion());

            txtStock.setText(
                    String.valueOf(existente.getStock())
            );

            txtMinimo.setText(
                    String.valueOf(existente.getStockMinimo())
            );

            txtCosto.setText(
                    String.valueOf(existente.getCostoUnitario())
            );
        }

        VBox contenido = new VBox(
                10,
                new Label("ID proveedor:"), txtProveedor,
                new Label("Código:"), txtCodigo,
                new Label("Nombre:"), txtNombre,
                new Label("Descripción:"), txtDescripcion,
                new Label("Stock:"), txtStock,
                new Label("Stock mínimo:"), txtMinimo,
                new Label("Costo unitario:"), txtCosto
        );

        contenido.setPadding(new Insets(20));
        contenido.setPrefWidth(450);

        dialogo.getDialogPane().setContent(contenido);

        dialogo.setResultConverter(boton -> {

            if (boton != guardar) {
                return null;
            }

            try {

                if (txtProveedor.getText().trim().isEmpty()
                        || txtCodigo.getText().trim().isEmpty()
                        || txtNombre.getText().trim().isEmpty()
                        || txtStock.getText().trim().isEmpty()
                        || txtMinimo.getText().trim().isEmpty()
                        || txtCosto.getText().trim().isEmpty()) {

                    mostrarError(
                            "Complete todos los campos obligatorios."
                    );

                    return null;
                }

                int proveedor = Integer.parseInt(
                        txtProveedor.getText().trim()
                );

                int stock = Integer.parseInt(
                        txtStock.getText().trim()
                );

                int minimo = Integer.parseInt(
                        txtMinimo.getText().trim()
                );

                double costo = Double.parseDouble(
                        txtCosto.getText().trim()
                );

                if (stock < 0 || minimo < 0 || costo < 0) {

                    mostrarError(
                            "Stock, mínimo y costo no pueden ser negativos."
                    );

                    return null;
                }

                Repuesto r = existente == null
                        ? new Repuesto()
                        : existente;

                r.setIdProveedor(proveedor);
                r.setCodigo(txtCodigo.getText().trim());
                r.setNombre(txtNombre.getText().trim());
                r.setDescripcion(
                        txtDescripcion.getText().trim()
                );
                r.setStock(stock);
                r.setStockMinimo(minimo);
                r.setCostoUnitario(costo);

                return r;

            } catch (NumberFormatException ex) {

                mostrarError(
                        "Verifique los campos numéricos."
                );

                return null;
            }
        });

        return dialogo;
    }

    private void cambiarEstado() {

        Repuesto seleccionado =
                tabla.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {

            mostrarError("Seleccione un repuesto.");
            return;
        }

        String nuevoEstado = seleccionado.isEstado()
                ? "Desactivar"
                : "Activar";

        Alert confirmacion = new Alert(
                Alert.AlertType.CONFIRMATION
        );

        confirmacion.setTitle("Cambiar estado");
        confirmacion.setHeaderText(
                seleccionado.getNombre()
        );

        confirmacion.setContentText(
                "¿Desea " + nuevoEstado.toLowerCase()
                + " este repuesto?"
        );

        confirmacion.showAndWait().ifPresent(respuesta -> {

            if (respuesta == ButtonType.OK) {

                boolean resultado = seleccionado.isEstado()
                        ? repuestoDAO.eliminar(
                                seleccionado.getIdRepuesto())
                        : repuestoDAO.activar(
                                seleccionado.getIdRepuesto());

                if (resultado) {

                    cargarRepuestos();

                    mostrarMensaje(
                            "Estado actualizado correctamente."
                    );

                } else {

                    mostrarError(
                            "No se pudo cambiar el estado."
                    );
                }
            }
        });
    }

    private void estilizarBoton(
            Button boton, boolean principal) {

        String color = principal
                ? "#E50914"
                : "#292A31";

        boton.setStyle(
                "-fx-background-color: " + color + ";"
                + "-fx-text-fill: white;"
                + "-fx-font-weight: bold;"
                + "-fx-background-radius: 6;"
                + "-fx-padding: 10 15 10 15;"
                + "-fx-cursor: hand;"
        );
    }

    private void mostrarMensaje(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void mostrarError(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setHeaderText("Atención");
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}