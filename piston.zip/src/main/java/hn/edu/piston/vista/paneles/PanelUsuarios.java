/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.impl.UsuarioDAOImpl;
import hn.edu.piston.modelo.Usuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.control.cell.PropertyValueFactory;
/**
 *
 * @author Alexander
 */
public class PanelUsuarios extends BorderPane {

    private final UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();

    private final TableView<Usuario> tabla = new TableView<>();
    private final ObservableList<Usuario> usuarios =
            FXCollections.observableArrayList();

    private TextField txtUsuario;
    private PasswordField txtContrasena;
    private ComboBox<String> cmbRol;
   // private TextField txtIdMecanico;

    private Button btnRegistrar;
    private Button btnActualizar;
    private Button btnEstado;
    private Button btnLimpiar;

    private Usuario usuarioSeleccionado;

    public PanelUsuarios() {
        construirInterfaz();
        configurarTabla();
        cargarUsuarios();
    }



    private void construirInterfaz() {

        setPadding(new Insets(15));

        Label titulo = new Label("Administración de usuarios");
        titulo.setStyle(
                "-fx-text-fill: #f5f5f7;"
                + "-fx-font-size: 20px;"
                + "-fx-font-weight: bold;"
        );

        Label descripcion = new Label(
                "Registro y control de acceso al sistema."
        );
        descripcion.setStyle("-fx-text-fill: #9999a5;");

        VBox encabezado = new VBox(8, titulo, descripcion);
        encabezado.setPadding(new Insets(0, 0, 20, 0));

        // FORMULARIO
        txtUsuario = new TextField();
        txtUsuario.setPromptText("Nombre de usuario");

        txtContrasena = new PasswordField();
        txtContrasena.setPromptText("Contraseña");

        cmbRol = new ComboBox<>();
        cmbRol.getItems().add("ADMIN");
        cmbRol.setValue("ADMIN");
        cmbRol.setDisable(true);
        cmbRol.setPromptText("Seleccionar rol");
        cmbRol.setMaxWidth(Double.MAX_VALUE);

      //   txtIdMecanico = new TextField();
      //  txtIdMecanico.setPromptText("ID del mecánico (opcional)");

        btnRegistrar = crearBoton("Registrar", "#ff304f");
        btnActualizar = crearBoton("Actualizar", "#30303a");
        btnEstado = crearBoton("Activar / Desactivar", "#30303a");
        btnLimpiar = crearBoton("Limpiar", "#30303a");

        btnRegistrar.setOnAction(e -> registrarUsuario());
        btnActualizar.setOnAction(e -> actualizarUsuario());
        btnEstado.setOnAction(e -> cambiarEstado());
        btnLimpiar.setOnAction(e -> limpiarFormulario());

        VBox formulario = new VBox(12);

        Label lblFormulario = new Label("DATOS DEL USUARIO");
        lblFormulario.setStyle(
                "-fx-text-fill: #ff304f;"
                + "-fx-font-weight: bold;"
        );

        formulario.getChildren().addAll(
                lblFormulario,
                txtUsuario,
                txtContrasena,
                cmbRol,
            //    txtIdMecanico,
                btnRegistrar,
                btnActualizar,
                btnEstado,
                btnLimpiar
        );

        formulario.setPadding(new Insets(20));
        formulario.setPrefWidth(260);
        formulario.setStyle(
                "-fx-background-color: #15151c;"
                + "-fx-background-radius: 10;"
        );

        // TABLA
        configurarTabla();

        VBox contenedorTabla = new VBox(10);

        Label lblTabla = new Label("USUARIOS REGISTRADOS");
        lblTabla.setStyle(
                "-fx-text-fill: #ff304f;"
                + "-fx-font-weight: bold;"
        );

        contenedorTabla.getChildren().addAll(lblTabla, tabla);
        VBox.setVgrow(tabla, Priority.ALWAYS);

        HBox cuerpo = new HBox(20, formulario, contenedorTabla);
        HBox.setHgrow(contenedorTabla, Priority.ALWAYS);
        VBox.setVgrow(tabla, Priority.ALWAYS);

        setTop(encabezado);
        setCenter(cuerpo);
    }

    

    private void configurarTabla() {

        TableColumn<Usuario, Integer> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                new PropertyValueFactory<>("idUsuario")
        );

        TableColumn<Usuario, String> colUsuario =
                new TableColumn<>("Usuario");

        colUsuario.setCellValueFactory(
                new PropertyValueFactory<>("usuario")
        );

        TableColumn<Usuario, String> colRol =
                new TableColumn<>("Rol");

        colRol.setCellValueFactory(
                new PropertyValueFactory<>("rol")
        );

        TableColumn<Usuario, Integer> colMecanico =
                new TableColumn<>("ID Mecánico");

        colMecanico.setCellValueFactory(
                new PropertyValueFactory<>("idMecanico")
        );

        TableColumn<Usuario, Boolean> colEstado =
                new TableColumn<>("Activo");

        colEstado.setCellValueFactory(
                new PropertyValueFactory<>("estado")
        );

        tabla.getColumns().setAll(
                colId,
                colUsuario,
                colRol,
                colMecanico,
                colEstado
        );

        tabla.setItems(usuarios);
        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY
        );

        tabla.setPlaceholder(
                new Label("No hay usuarios registrados.")
        );

        tabla.setStyle("-fx-background-color: #15151c;");

        tabla.getSelectionModel()
                .selectedItemProperty()
                .addListener((obs, anterior, seleccionado) -> {

                    if (seleccionado != null) {
                        usuarioSeleccionado = seleccionado;

                        txtUsuario.setText(
                                seleccionado.getUsuario()
                        );

                        cmbRol.setValue(
                                seleccionado.getRol()
                        );

                        
                    }
                });
    }



    private void registrarUsuario() {

        try {

            if (txtUsuario.getText().trim().isEmpty()
                    || txtContrasena.getText().isEmpty()
                    || cmbRol.getValue() == null) {

                mostrarAlerta(
                        Alert.AlertType.WARNING,
                        "Completa el usuario, contraseña y rol."
                );
                return;
            }

            Usuario usuario = construirUsuario();

            usuario.setEstado(true);

            if (usuarioDAO.registrar(usuario)) {

                mostrarAlerta(
                        Alert.AlertType.INFORMATION,
                        "Usuario registrado correctamente."
                );

                cargarUsuarios();
                limpiarFormulario();

            } else {

                mostrarAlerta(
                        Alert.AlertType.ERROR,
                        "No se pudo registrar el usuario."
                );
            }

        } catch (Exception ex) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Error al registrar: " + ex.getMessage()
            );
        }
    }



    private void actualizarUsuario() {

        if (usuarioSeleccionado == null) {
            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Selecciona un usuario de la tabla."
            );
            return;
        }

        try {

            if (txtUsuario.getText().trim().isEmpty()
                    || txtContrasena.getText().isEmpty()
                    || cmbRol.getValue() == null) {

                mostrarAlerta(
                        Alert.AlertType.WARNING,
                        "Para actualizar debes completar "
                        + "usuario, contraseña y rol."
                );
                return;
            }

            Usuario usuario = construirUsuario();

            usuario.setIdUsuario(
                    usuarioSeleccionado.getIdUsuario()
            );

            usuario.setEstado(
                    usuarioSeleccionado.isEstado()
            );

            if (usuarioDAO.actualizar(usuario)) {

                mostrarAlerta(
                        Alert.AlertType.INFORMATION,
                        "Usuario actualizado correctamente."
                );

                cargarUsuarios();
                limpiarFormulario();

            } else {

                mostrarAlerta(
                        Alert.AlertType.ERROR,
                        "No se pudo actualizar el usuario."
                );
            }

        } catch (Exception ex) {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "Error al actualizar: " + ex.getMessage()
            );
        }
    }



    private void cambiarEstado() {

    if (usuarioSeleccionado == null) {
        mostrarAlerta(
                Alert.AlertType.WARNING,
                "Selecciona un usuario de la tabla."
        );
        return;
    }

    int idUsuario = usuarioSeleccionado.getIdUsuario();
    boolean nuevoEstado = !usuarioSeleccionado.isEstado();

    try {

        if (usuarioDAO.cambiarEstado(idUsuario, nuevoEstado)) {

            cargarUsuarios();

            // Recuperar el usuario actualizado en la tabla
            for (Usuario u : usuarios) {
                if (u.getIdUsuario() == idUsuario) {

                    usuarioSeleccionado = u;

                    tabla.getSelectionModel().select(u);
                    tabla.scrollTo(u);

                    break;
                }
            }

            mostrarAlerta(
                    Alert.AlertType.INFORMATION,
                    nuevoEstado
                    ? "Usuario activado."
                    : "Usuario desactivado."
            );

        } else {

            mostrarAlerta(
                    Alert.AlertType.ERROR,
                    "No se pudo cambiar el estado."
            );
        }

    } catch (Exception ex) {

        mostrarAlerta(
                Alert.AlertType.ERROR,
                "Error: " + ex.getMessage()
        );
    }
}
  

 
private Usuario construirUsuario() {

    Usuario usuario = new Usuario();

    usuario.setUsuario(txtUsuario.getText().trim());
    usuario.setContrasena(txtContrasena.getText());
    usuario.setRol("ADMIN");
    usuario.setIdMecanico(null);

    return usuario;
}


    private void limpiarFormulario() {

        usuarioSeleccionado = null;

        txtUsuario.clear();
        txtContrasena.clear();
      //  txtIdMecanico.clear();
        cmbRol.getSelectionModel().clearSelection();

        tabla.getSelectionModel().clearSelection();

        btnRegistrar.setDisable(false);
        btnActualizar.setDisable(true);
        btnEstado.setDisable(true);
    }



    private void cargarUsuarios() {

        usuarios.clear();

        usuarios.addAll(usuarioDAO.listar());

        tabla.refresh();
    }



    private Button crearBoton(String texto, String color) {

        Button boton = new Button(texto);

        boton.setMaxWidth(Double.MAX_VALUE);
        boton.setPrefHeight(38);

        boton.setStyle(
                "-fx-background-color: " + color + ";"
                + "-fx-text-fill: white;"
                + "-fx-background-radius: 6;"
                + "-fx-cursor: hand;"
        );

        return boton;
    }

    private void mostrarAlerta(
            Alert.AlertType tipo,
            String mensaje
    ) {

        Alert alerta = new Alert(tipo);
        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}