/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.dao.OrdenTrabajoDAO;
import hn.edu.piston.daoimpl.OrdenTrabajoDAOImpl;
import hn.edu.piston.modelo.OrdenTrabajo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import hn.edu.piston.modelo.Cliente;
import hn.edu.piston.daoimpl.ClienteDAOImpl;
import hn.edu.piston.dao.ClienteDAO;
import java.time.format.DateTimeFormatter;
import javafx.scene.control.ListCell;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
/**
 *
 * @author Alexander
 */
public class PanelOrdenes extends BorderPane {

    private final OrdenTrabajoDAO ordenDAO = new OrdenTrabajoDAOImpl();
    private final ClienteDAO clienteDAO = new ClienteDAOImpl();
    private final ObservableList<Cliente> clientesActivos =
        FXCollections.observableArrayList();
    private final TableView<OrdenTrabajo> tabla = new TableView<>();
    private final ObservableList<OrdenTrabajo> lista =
            FXCollections.observableArrayList();

    private final TextField txtBuscar = new TextField();

    private final Button btnRegistrar = new Button("Registrar orden");
    private final Button btnCambiarEstado = new Button("Cambiar estado");

public PanelOrdenes() {
    construirInterfaz();
    configurarTabla();
    configurarEstiloEncabezados();
    cargarOrdenes();
}

    private void construirInterfaz() {

        setPadding(new Insets(20));
        setStyle("-fx-background-color: #111318;");

        Label titulo = new Label("Órdenes de trabajo");
        titulo.setStyle(
                "-fx-font-size: 24px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: white;"
        );

        Label subtitulo = new Label(
                "Control de reparaciones y mantenimiento del taller"
        );
        subtitulo.setStyle("-fx-text-fill: #A0A0A0;");
VBox encabezado = new VBox(5, titulo, subtitulo);

txtBuscar.setPromptText("Buscar por orden, placa o cliente...");
txtBuscar.setPrefWidth(300);

txtBuscar.setStyle(
        "-fx-background-color: #202127;"
        + "-fx-text-fill: white;"
        + "-fx-prompt-text-fill: #777777;"
        + "-fx-background-radius: 6;"
        + "-fx-border-color: #34343A;"
        + "-fx-border-radius: 6;"
);

estilizarBoton(btnRegistrar, true);
estilizarBoton(btnCambiarEstado, false);

HBox barra = new HBox(
        10, txtBuscar, btnRegistrar, btnCambiarEstado
);

barra.setPadding(new Insets(20, 0, 15, 0));
barra.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

setTop(encabezado);

tabla.setItems(lista);
tabla.setColumnResizePolicy(
        TableView.CONSTRAINED_RESIZE_POLICY
);

tabla.setStyle(
        "-fx-background-color: #202127;"
        + "-fx-control-inner-background: #202127;"
        + "-fx-text-background-color: white;"
);

// PESTAÑA DE ORDENES
VBox panelOrdenes = new VBox(10);
panelOrdenes.getChildren().addAll(barra, tabla);
VBox.setVgrow(tabla, Priority.ALWAYS);

        // PESTAÑA DE DIAGNÓSTICOS
        PanelDiagnosticos panelDiagnosticos =
                new PanelDiagnosticos();

        // PESTAÑA DE ACTIVIDADES
        PanelActividades panelActividades =
                new PanelActividades();

        // PESTAÑAS
        Tab tabOrdenes =
                new Tab("Órdenes", panelOrdenes);

        Tab tabDiagnosticos =
                new Tab("Diagnósticos", panelDiagnosticos);

        Tab tabActividades =
                new Tab("Actividades", panelActividades);

        tabOrdenes.setClosable(false);
        tabDiagnosticos.setClosable(false);
        tabActividades.setClosable(false);

        TabPane pestañas = new TabPane(
                tabOrdenes,
                tabDiagnosticos,
                tabActividades
        );

pestañas.setTabClosingPolicy(
        TabPane.TabClosingPolicy.UNAVAILABLE
);

pestañas.setStyle(
        "-fx-background-color: #111318;"
);

setCenter(pestañas);

btnCambiarEstado.setOnAction(e -> cambiarEstadoOrden());
btnRegistrar.setOnAction(e -> registrarOrden());

txtBuscar.textProperty().addListener(
        (observable, anterior, nuevo) -> buscarOrdenes(nuevo)
);

tabla.setRowFactory(tv -> {

    TableRow<OrdenTrabajo> fila = new TableRow<>();

    fila.setOnMouseClicked(evento -> {

        if (evento.getClickCount() == 2
                && !fila.isEmpty()) {

            editarOrden(fila.getItem());
        }
    });

    return fila;
});

        btnCambiarEstado.setOnAction(e -> cambiarEstadoOrden());
        btnRegistrar.setOnAction(e -> registrarOrden());

        txtBuscar.textProperty().addListener(
                (observable, anterior, nuevo) -> buscarOrdenes(nuevo)
        );

        tabla.setRowFactory(tv -> {

            TableRow<OrdenTrabajo> fila = new TableRow<>();

            fila.setOnMouseClicked(evento -> {

                if (evento.getClickCount() == 2
                        && !fila.isEmpty()) {

                    editarOrden(fila.getItem());
                }
            });

            return fila;
        });
    }

    private void configurarTabla() {

        TableColumn<OrdenTrabajo, Number> colId =
                new TableColumn<>("Orden");

        colId.setCellValueFactory(datos ->
                new SimpleIntegerProperty(
                        datos.getValue().getIdOrden()
                )
        );

        TableColumn<OrdenTrabajo, String> colCliente =
                new TableColumn<>("Cliente");

        colCliente.setCellValueFactory(datos ->
                new SimpleStringProperty(
                        datos.getValue().getCliente()
                )
        );

        TableColumn<OrdenTrabajo, String> colPlaca =
                new TableColumn<>("Placa");

        colPlaca.setCellValueFactory(datos ->
                new SimpleStringProperty(
                        datos.getValue().getPlaca()
                )
        );

        TableColumn<OrdenTrabajo, String> colVehiculo =
                new TableColumn<>("Vehículo");

        colVehiculo.setCellValueFactory(datos ->
                new SimpleStringProperty(
                        datos.getValue().getMarca() + " "
                        + datos.getValue().getModelo()
                )
        );

        TableColumn<OrdenTrabajo, String> colFecha =
                new TableColumn<>("Fecha ingreso");

        colFecha.setCellValueFactory(datos -> {

            if (datos.getValue().getFechaInicio() == null) {
                return new SimpleStringProperty("");
            }

            return new SimpleStringProperty(
                    datos.getValue().getFechaInicio().format(
                            DateTimeFormatter.ofPattern(
                                    "dd/MM/yyyy HH:mm"
                            )
                    )
            );
        });

        TableColumn<OrdenTrabajo, Number> colKilometraje =
                new TableColumn<>("Kilometraje");

        colKilometraje.setCellValueFactory(datos ->
                new SimpleIntegerProperty(
                        datos.getValue().getKilometraje()
                )
        );

        TableColumn<OrdenTrabajo, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(datos ->
                new SimpleStringProperty(
                        datos.getValue().getEstado()
                )
        );

        tabla.getColumns().addAll(
                colId, colCliente, colPlaca, colVehiculo,
                colFecha, colKilometraje, colEstado
        );
    }

    private void cargarOrdenes() {
        lista.setAll(ordenDAO.listar());
    }
    
    private void cambiarEstadoOrden() {

    OrdenTrabajo seleccionada =
            tabla.getSelectionModel().getSelectedItem();

    if (seleccionada == null) {
        mostrarError("Seleccione una orden de trabajo.");
        return;
    }

    String estadoActual = seleccionada.getEstado();

    String nuevoEstado;

    if ("En proceso".equalsIgnoreCase(estadoActual)) {
        nuevoEstado = "Finalizada";
    } else {
        nuevoEstado = "En proceso";
    }

    Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);

    confirmacion.setTitle("Cambiar estado");
    confirmacion.setHeaderText(
            "Orden de trabajo #" + seleccionada.getIdOrden()
    );

    confirmacion.setContentText(
            "¿Desea cambiar el estado de "
            + estadoActual + " a " + nuevoEstado + "?"
    );

    confirmacion.showAndWait().ifPresent(respuesta -> {

        if (respuesta == ButtonType.OK) {

            if (ordenDAO.cambiarEstado(
                    seleccionada.getIdOrden(), nuevoEstado)) {

                cargarOrdenes();

                mostrarMensaje(
                        "La orden ahora está: " + nuevoEstado
                );

            } else {
                mostrarError("No se pudo cambiar el estado.");
            }
        }
    });
}

    private void editarOrden(OrdenTrabajo orden) {

    Dialog<OrdenTrabajo> dialogo = new Dialog<>();

    dialogo.setTitle(
            "Editar orden #" + orden.getIdOrden()
    );

    ButtonType guardar = new ButtonType(
            "Guardar cambios",
            ButtonBar.ButtonData.OK_DONE
    );

    dialogo.getDialogPane().getButtonTypes().addAll(
            guardar, ButtonType.CANCEL
    );

    TextField txtKilometraje = new TextField(
            String.valueOf(orden.getKilometraje())
    );

    TextArea txtSintomas = new TextArea(
            orden.getSintomas()
    );

    TextArea txtDiagnostico = new TextArea(
            orden.getDiagnosticoPreliminar() == null
                    ? ""
                    : orden.getDiagnosticoPreliminar()
    );

    txtSintomas.setWrapText(true);
    txtDiagnostico.setWrapText(true);

    txtSintomas.setPrefRowCount(3);
    txtDiagnostico.setPrefRowCount(3);

    VBox contenido = new VBox(
            12,
            new Label("Kilometraje:"),
            txtKilometraje,
            new Label("Síntomas:"),
            txtSintomas,
            new Label("Diagnóstico preliminar:"),
            txtDiagnostico
    );

    contenido.setPadding(new Insets(20));
    contenido.setPrefWidth(470);

    dialogo.getDialogPane().setContent(contenido);

    dialogo.setResultConverter(boton -> {

        if (boton != guardar) {
            return null;
        }

        if (txtKilometraje.getText().trim().isEmpty()
                || txtSintomas.getText().trim().isEmpty()) {

            mostrarError(
                    "Complete el kilometraje y los síntomas."
            );

            return null;
        }

        try {

            int kilometraje = Integer.parseInt(
                    txtKilometraje.getText().trim()
            );

            if (kilometraje < 0) {
                mostrarError(
                        "El kilometraje no puede ser negativo."
                );
                return null;
            }

            orden.setKilometraje(kilometraje);
            orden.setSintomas(txtSintomas.getText().trim());

            String diagnostico =
                    txtDiagnostico.getText().trim();

            orden.setDiagnosticoPreliminar(
                    diagnostico.isEmpty()
                            ? null
                            : diagnostico
            );

            return orden;

        } catch (NumberFormatException ex) {

            mostrarError(
                    "El kilometraje debe ser un número entero."
            );

            return null;
        }
    });

    dialogo.showAndWait().ifPresent(ordenEditada -> {

        if (ordenDAO.actualizar(ordenEditada)) {

            cargarOrdenes();

            mostrarMensaje(
                    "Orden de trabajo actualizada correctamente."
            );

        } else {
            mostrarError(
                    "No se pudieron guardar los cambios."
            );
        }
    });
}
    
    private void buscarOrdenes(String texto) {

        if (texto == null || texto.trim().isEmpty()) {
            cargarOrdenes();
            return;
        }

        String busqueda = texto.toLowerCase().trim();

        ObservableList<OrdenTrabajo> filtrados =
                FXCollections.observableArrayList();

        for (OrdenTrabajo o : ordenDAO.listar()) {

            String id = String.valueOf(o.getIdOrden());

            if (id.contains(busqueda)
                    || o.getPlaca().toLowerCase().contains(busqueda)
                    || o.getCliente().toLowerCase().contains(busqueda)) {

                filtrados.add(o);
            }
        }

        lista.setAll(filtrados);
    }

    private void registrarOrden() {

        Dialog<OrdenTrabajo> dialogo = crearFormulario();

        dialogo.showAndWait().ifPresent(orden -> {

            if (ordenDAO.insertar(orden)) {

                cargarOrdenes();

                mostrarMensaje(
                        "Orden de trabajo registrada correctamente."
                );

            } else {

                mostrarError(
                        "No se pudo registrar la orden de trabajo."
                );
            }
        });
    }

private Dialog<OrdenTrabajo> crearFormulario() {

    Dialog<OrdenTrabajo> dialogo = new Dialog<>();
    dialogo.setTitle("Registrar orden de trabajo");

    ButtonType guardar = new ButtonType(
            "Guardar", ButtonBar.ButtonData.OK_DONE
    );

    dialogo.getDialogPane().getButtonTypes().addAll(
            guardar, ButtonType.CANCEL
    );

    // DAO
    ClienteDAO clienteDAO = new ClienteDAOImpl();
    hn.edu.piston.dao.VehiculoDAO vehiculoDAO =
            new hn.edu.piston.daoimpl.VehiculoDAOImpl();

    // Listas
    ObservableList<Cliente> clientes =
            FXCollections.observableArrayList();

    ObservableList<Cliente> clientesFiltrados =
            FXCollections.observableArrayList();

    ObservableList<hn.edu.piston.modelo.Vehiculo> vehiculosCliente =
            FXCollections.observableArrayList();

    // Cargar clientes activos
    clientes.setAll(
            clienteDAO.listar().stream()
                    .filter(Cliente::isEstado)
                    .toList()
    );

    // BUSCADOR
    TextField txtBuscarCliente = new TextField();
    txtBuscarCliente.setPromptText(
            "Buscar cliente por nombre o DNI..."
    );

    // COMBO CLIENTES
    ComboBox<Cliente> cmbCliente = new ComboBox<>();
    cmbCliente.setPromptText("Seleccionar cliente");
    cmbCliente.setMaxWidth(Double.MAX_VALUE);

    // Mostrar inicialmente todos los clientes
    clientesFiltrados.setAll(clientes);
    cmbCliente.setItems(clientesFiltrados);

    // Mostrar nombre y DNI
    cmbCliente.setCellFactory(lv -> new ListCell<>() {
        @Override
        protected void updateItem(Cliente c, boolean empty) {
            super.updateItem(c, empty);

            setText(empty || c == null
                    ? null
                    : c.getNombre() + " - DNI: " + c.getDni());
        }
    });

    cmbCliente.setButtonCell(new ListCell<>() {
        @Override
        protected void updateItem(Cliente c, boolean empty) {
            super.updateItem(c, empty);

            setText(empty || c == null
                    ? null
                    : c.getNombre() + " - DNI: " + c.getDni());
        }
    });

    // COMBO VEHICULOS
    ComboBox<hn.edu.piston.modelo.Vehiculo> cmbVehiculo =
            new ComboBox<>();

    cmbVehiculo.setPromptText("Seleccionar vehículo");
    cmbVehiculo.setMaxWidth(Double.MAX_VALUE);
    cmbVehiculo.setItems(vehiculosCliente);
    cmbVehiculo.setDisable(true);

    cmbVehiculo.setCellFactory(lv -> new ListCell<>() {
        @Override
        protected void updateItem(
                hn.edu.piston.modelo.Vehiculo v,
                boolean empty) {

            super.updateItem(v, empty);

            setText(empty || v == null
                    ? null
                    : v.getPlaca() + " - "
                    + v.getMarca() + " " + v.getModelo());
        }
    });

    cmbVehiculo.setButtonCell(new ListCell<>() {
        @Override
        protected void updateItem(
                hn.edu.piston.modelo.Vehiculo v,
                boolean empty) {

            super.updateItem(v, empty);

            setText(empty || v == null
                    ? null
                    : v.getPlaca() + " - "
                    + v.getMarca() + " " + v.getModelo());
        }
    });

    // FILTRAR CLIENTES
    txtBuscarCliente.textProperty().addListener(
            (obs, anterior, texto) -> {

        String filtro = texto == null
                ? ""
                : texto.trim().toLowerCase();

        clientesFiltrados.clear();

        for (Cliente c : clientes) {

            String nombre = c.getNombre() == null
                    ? ""
                    : c.getNombre().toLowerCase();

            String dni = c.getDni() == null
                    ? ""
                    : c.getDni().toLowerCase();

            if (nombre.contains(filtro)
                    || dni.contains(filtro)) {

                clientesFiltrados.add(c);
            }
        }

        cmbCliente.getSelectionModel().clearSelection();
        cmbCliente.setValue(null);

        vehiculosCliente.clear();
        cmbVehiculo.setValue(null);
        cmbVehiculo.setDisable(true);
    });

    // SELECCIONAR CLIENTE Y CARGAR VEHICULOS
    cmbCliente.setOnAction(e -> {

        Cliente seleccionado = cmbCliente.getValue();

        vehiculosCliente.clear();
        cmbVehiculo.setValue(null);
        cmbVehiculo.setDisable(true);

        if (seleccionado == null) {
            return;
        }

        for (hn.edu.piston.modelo.Vehiculo v
                : vehiculoDAO.listar()) {

            if (v.isEstado()
                    && v.getIdCliente()
                    == seleccionado.getIdCliente()) {

                vehiculosCliente.add(v);
            }
        }

        cmbVehiculo.setDisable(
                vehiculosCliente.isEmpty()
        );

        if (vehiculosCliente.isEmpty()) {
            mostrarMensaje(
                    "Este cliente no tiene vehículos activos registrados."
            );
        }
    });

    // CAMPOS
    TextField txtKilometraje = new TextField();
    TextArea txtSintomas = new TextArea();

    txtKilometraje.setPromptText("Kilometraje actual");

    txtSintomas.setPromptText(
            "Describe los problemas reportados por el cliente"
    );

    txtSintomas.setPrefRowCount(4);
    txtSintomas.setWrapText(true);

    // DISEÑO
    VBox contenido = new VBox(
            12,
            new Label("Buscar cliente:"),
            txtBuscarCliente,
            new Label("Cliente:"),
            cmbCliente,
            new Label("Vehículo:"),
            cmbVehiculo,
            new Label("Kilometraje:"),
            txtKilometraje,
            new Label("Síntomas:"),
            txtSintomas
    );

    contenido.setPadding(new Insets(20));
    contenido.setPrefWidth(470);

    dialogo.getDialogPane().setContent(contenido);

    // GUARDAR
    dialogo.setResultConverter(boton -> {

        if (boton != guardar) {
            return null;
        }

        if (cmbCliente.getValue() == null
                || cmbVehiculo.getValue() == null
                || txtKilometraje.getText().trim().isEmpty()
                || txtSintomas.getText().trim().isEmpty()) {

            mostrarError(
                    "Seleccione cliente y vehículo, y complete los campos obligatorios."
            );

            return null;
        }

        try {

            int kilometraje = Integer.parseInt(
                    txtKilometraje.getText().trim()
            );

            if (kilometraje < 0) {
                mostrarError(
                        "El kilometraje no puede ser negativo."
                );
                return null;
            }

            OrdenTrabajo o = new OrdenTrabajo();

            o.setIdVehiculo(
                    cmbVehiculo.getValue().getIdVehiculo()
            );

            o.setKilometraje(kilometraje);
            o.setSintomas(txtSintomas.getText().trim());

            return o;

        } catch (NumberFormatException ex) {

            mostrarError(
                    "El kilometraje debe ser un número entero."
            );

            return null;
        }
    });

    return dialogo;
}

    private void consultarOrden(OrdenTrabajo o) {

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);

        alerta.setTitle("Orden de trabajo #" + o.getIdOrden());
        alerta.setHeaderText(
                o.getMarca() + " " + o.getModelo()
                + " - " + o.getPlaca()
        );

        alerta.setContentText(
                "Cliente: " + o.getCliente()
                + "\nEstado: " + o.getEstado()
                + "\nKilometraje: " + o.getKilometraje()
                + "\nSíntomas: " + o.getSintomas()
                + "\nDiagnóstico: "
                + (o.getDiagnosticoPreliminar() == null
                        ? "Pendiente"
                        : o.getDiagnosticoPreliminar())
        );

        alerta.showAndWait();
    }

    private void mostrarMensaje(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);

        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }

    private void mostrarError(String mensaje) {

        Alert alerta = new Alert(Alert.AlertType.ERROR);

        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText("Atención");
        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }

    private void estilizarBoton(Button boton, boolean principal) {

        String color = principal ? "#E50914" : "#292A31";

        boton.setStyle(
                "-fx-background-color: " + color + ";"
                + "-fx-text-fill: white;"
                + "-fx-font-weight: bold;"
                + "-fx-background-radius: 6;"
                + "-fx-padding: 10 15 10 15;"
        );
    }
    
    private void configurarEstiloEncabezados() {

    tabla.skinProperty().addListener((observable, anterior, nuevo) -> {

        javafx.application.Platform.runLater(() -> {

            tabla.lookupAll(".column-header").forEach(nodo -> {

                nodo.setStyle(
                        "-fx-background-color: #DCDCDC;"
                        + "-fx-border-color: #B5B5B5;"
                        + "-fx-border-width: 0 1 1 0;"
                );

            });

            tabla.lookupAll(".column-header .label").forEach(nodo -> {

                nodo.setStyle(
                        "-fx-text-fill: black;"
                        + "-fx-font-weight: bold;"
                        + "-fx-alignment: CENTER;"
                );

            });

            tabla.lookupAll(".filler").forEach(nodo -> {

                nodo.setStyle("-fx-background-color: #DCDCDC;");

            });

        });

    });
}
}
