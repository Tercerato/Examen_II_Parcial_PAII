/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.daoimpl.ClienteDAOImpl;
import hn.edu.piston.daoimpl.VehiculoDAOImpl;
import hn.edu.piston.modelo.Cliente;
import hn.edu.piston.modelo.Vehiculo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class PanelVehiculos extends VBox {

    private final VehiculoDAOImpl vehiculoDAO = new VehiculoDAOImpl();
    private final ClienteDAOImpl clienteDAO = new ClienteDAOImpl();

    private final TableView<Vehiculo> tabla = new TableView<>();
    private final ObservableList<Vehiculo> datos =
            FXCollections.observableArrayList();
    private FilteredList<Vehiculo> filtrados;

    private final TextField txtBuscar = new TextField();

    public PanelVehiculos() {

        setSpacing(20);
        setPadding(new Insets(25));
        setStyle("-fx-background-color: #111318;");

        crearTabla();
        crearInterfaz();
        cargarVehiculos();
    }



    private void crearInterfaz() {

        Label titulo = new Label("Gestión de vehículos");
        titulo.setStyle(
                "-fx-font-size: 25px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: white;"
        );

        Label subtitulo = new Label(
                "Administra los vehículos registrados en el taller"
        );
        subtitulo.setStyle("-fx-text-fill: #9CA3AF;");

        VBox encabezado = new VBox(5, titulo, subtitulo);

        txtBuscar.setPromptText(
                "Buscar por placa, VIN, marca o modelo..."
        );
        txtBuscar.setPrefWidth(350);
        txtBuscar.setStyle(
                "-fx-background-color: #1C1F26;"
                + "-fx-text-fill: white;"
                + "-fx-prompt-text-fill: #777;"
                + "-fx-background-radius: 8;"
                + "-fx-border-color: #343943;"
                + "-fx-border-radius: 8;"
        );

        txtBuscar.textProperty().addListener(
                (observable, anterior, actual) -> filtrarVehiculos()
        );

Button btnNuevo = crearBoton("＋ Registrar vehículo", true);
Button btnEstado = crearBoton("Activar / Desactivar", false);
Button btnActualizar = crearBoton("Actualizar", false);

btnNuevo.setOnAction(e -> mostrarFormulario(null));
btnEstado.setOnAction(e -> cambiarEstado());
btnActualizar.setOnAction(e -> cargarVehiculos());

HBox herramientas = new HBox(
        10, txtBuscar, btnActualizar, btnNuevo, btnEstado
);
herramientas.setAlignment(Pos.CENTER_LEFT);

VBox contenedorTabla = new VBox(10, tabla);

        VBox.setVgrow(tabla, Priority.ALWAYS);

        getChildren().addAll(encabezado, herramientas, contenedorTabla);
        VBox.setVgrow(contenedorTabla, Priority.ALWAYS);
    }



    private void crearTabla() {

        TableColumn<Vehiculo, Integer> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                new PropertyValueFactory<>("idVehiculo")
        );
        colId.setPrefWidth(55);

        TableColumn<Vehiculo, String> colPlaca =
                new TableColumn<>("Placa");

        colPlaca.setCellValueFactory(
                new PropertyValueFactory<>("placa")
        );
        colPlaca.setPrefWidth(100);

        TableColumn<Vehiculo, String> colMarca =
                new TableColumn<>("Marca");

        colMarca.setCellValueFactory(
                new PropertyValueFactory<>("marca")
        );
        colMarca.setPrefWidth(110);

        TableColumn<Vehiculo, String> colModelo =
                new TableColumn<>("Modelo");

        colModelo.setCellValueFactory(
                new PropertyValueFactory<>("modelo")
        );
        colModelo.setPrefWidth(110);

        TableColumn<Vehiculo, Integer> colAnio =
                new TableColumn<>("Año");

        colAnio.setCellValueFactory(
                new PropertyValueFactory<>("anio")
        );
        colAnio.setPrefWidth(70);

        TableColumn<Vehiculo, String> colPropietario =
                new TableColumn<>("Propietario");
        
        TableColumn<Vehiculo, String> colVin =
        new TableColumn<>("VIN");

colVin.setCellValueFactory(
        new PropertyValueFactory<>("vin")
);

TableColumn<Vehiculo, String> colColor =
        new TableColumn<>("Color");

colColor.setCellValueFactory(
        new PropertyValueFactory<>("color")
);

TableColumn<Vehiculo, String> colCombustible =
        new TableColumn<>("Combustible");

colCombustible.setCellValueFactory(
        new PropertyValueFactory<>("combustible")
);

        colPropietario.setCellValueFactory(cell -> {
            Cliente cliente = clienteDAO.buscarPorId(
                    cell.getValue().getIdCliente()
            );

            return new javafx.beans.property.SimpleStringProperty(
                    cliente != null ? cliente.getNombre() : "Desconocido"
            );
        });
        colPropietario.setPrefWidth(200);

        TableColumn<Vehiculo, Integer> colKilometraje =
                new TableColumn<>("Kilometraje");

        colKilometraje.setCellValueFactory(
                new PropertyValueFactory<>("kilometraje")
        );
        colKilometraje.setPrefWidth(120);

        TableColumn<Vehiculo, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().isEstado()
                                ? "Activo" : "Inactivo"
                )
        );
        colEstado.setPrefWidth(90);

tabla.getColumns().addAll(
        colId,
        colPropietario,
        colPlaca,
        colVin,
        colMarca,
        colModelo,
        colAnio,
        colColor,
        colKilometraje,
        colCombustible,
        colEstado
);

        tabla.setColumnResizePolicy(
                TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN
        );

        tabla.setPlaceholder(
                new Label("No hay vehículos registrados")
        );

        tabla.setStyle(
                "-fx-background-color: #1C1F26;"
                + "-fx-control-inner-background: #1C1F26;"
                + "-fx-text-fill: white;"
        );

        tabla.setPrefHeight(500);

        tabla.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2
                    && tabla.getSelectionModel().getSelectedItem() != null) {
                editarVehiculo();
            }
        });
    }



    private void cargarVehiculos() {

        datos.setAll(vehiculoDAO.listar());

        filtrados = new FilteredList<>(datos, p -> true);

        tabla.setItems(filtrados);

        filtrarVehiculos();
    }

    private void filtrarVehiculos() {

        if (filtrados == null) {
            return;
        }

        String texto = txtBuscar.getText() == null
                ? ""
                : txtBuscar.getText().toLowerCase().trim();

        filtrados.setPredicate(v -> {

            if (texto.isEmpty()) {
                return true;
            }

            return v.getPlaca().toLowerCase().contains(texto)
                    || v.getVin().toLowerCase().contains(texto)
                    || v.getMarca().toLowerCase().contains(texto)
                    || v.getModelo().toLowerCase().contains(texto);
        });
    }



    private void mostrarFormulario(Vehiculo vehiculo) {

        boolean editar = vehiculo != null;

        Dialog<Vehiculo> dialog = new Dialog<>();

        dialog.setTitle(
                editar ? "Editar vehículo" : "Registrar vehículo"
        );

        dialog.setHeaderText(
                editar
                        ? "Modificar información del vehículo"
                        : "Registrar un vehículo nuevo"
        );

        ButtonType guardar = new ButtonType(
                editar ? "Guardar cambios" : "Registrar",
                ButtonBar.ButtonData.OK_DONE
        );

        dialog.getDialogPane().getButtonTypes().addAll(
                guardar,
                ButtonType.CANCEL
        );

        TextField txtPlaca = new TextField();
        TextField txtVin = new TextField();
        TextField txtMarca = new TextField();
        TextField txtModelo = new TextField();
        TextField txtAnio = new TextField();
        TextField txtColor = new TextField();
        TextField txtKilometraje = new TextField();

        ComboBox<String> cmbCombustible = new ComboBox<>();
        cmbCombustible.getItems().addAll(
                "Gasolina",
                "Diesel",
                "Híbrido",
                "Eléctrico",
                "Otro"
        );
        cmbCombustible.setPromptText("Seleccionar combustible");

        ComboBox<Cliente> cmbCliente = new ComboBox<>();

        List<Cliente> clientes = clienteDAO.listar();

        clientes.stream()
                .filter(Cliente::isEstado)
                .forEach(cmbCliente.getItems()::add);

        cmbCliente.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Cliente cliente, boolean empty) {
                super.updateItem(cliente, empty);
                setText(empty || cliente == null
                        ? null : cliente.getNombre());
            }
        });

        cmbCliente.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Cliente cliente, boolean empty) {
                super.updateItem(cliente, empty);
                setText(empty || cliente == null
                        ? null : cliente.getNombre());
            }
        });

        if (editar) {

            txtPlaca.setText(vehiculo.getPlaca());
            txtVin.setText(vehiculo.getVin());
            txtMarca.setText(vehiculo.getMarca());
            txtModelo.setText(vehiculo.getModelo());
            txtAnio.setText(String.valueOf(vehiculo.getAnio()));
            txtColor.setText(vehiculo.getColor());
            txtKilometraje.setText(
                    String.valueOf(vehiculo.getKilometraje())
            );

            cmbCombustible.setValue(vehiculo.getCombustible());

            clientes.stream()
                    .filter(c -> c.getIdCliente()
                            == vehiculo.getIdCliente())
                    .findFirst()
                    .ifPresent(cmbCliente::setValue);
        }

        GridPane formulario = new GridPane();

        formulario.setHgap(15);
        formulario.setVgap(12);
        formulario.setPadding(new Insets(15));

        formulario.add(new Label("Propietario:"), 0, 0);
        formulario.add(cmbCliente, 1, 0);

        formulario.add(new Label("Placa:"), 0, 1);
        formulario.add(txtPlaca, 1, 1);

        formulario.add(new Label("VIN:"), 0, 2);
        formulario.add(txtVin, 1, 2);

        formulario.add(new Label("Marca:"), 0, 3);
        formulario.add(txtMarca, 1, 3);

        formulario.add(new Label("Modelo:"), 0, 4);
        formulario.add(txtModelo, 1, 4);

        formulario.add(new Label("Año:"), 0, 5);
        formulario.add(txtAnio, 1, 5);

        formulario.add(new Label("Color:"), 0, 6);
        formulario.add(txtColor, 1, 6);

        formulario.add(new Label("Kilometraje:"), 0, 7);
        formulario.add(txtKilometraje, 1, 7);

        formulario.add(new Label("Combustible:"), 0, 8);
        formulario.add(cmbCombustible, 1, 8);

        dialog.getDialogPane().setContent(formulario);

        dialog.getDialogPane().setPrefWidth(450);

        Button btnGuardar = (Button) dialog.getDialogPane()
                .lookupButton(guardar);

        btnGuardar.addEventFilter(
                javafx.event.ActionEvent.ACTION,
                event -> {

                    if (!validarFormulario(
                            cmbCliente,
                            txtPlaca,
                            txtVin,
                            txtMarca,
                            txtModelo,
                            txtAnio,
                            txtKilometraje,
                            cmbCombustible)) {

                        event.consume();
                    }
                }
        );

        dialog.setResultConverter(button -> {

            if (button == guardar) {

                Vehiculo v = editar
                        ? vehiculo
                        : new Vehiculo();

                v.setIdCliente(
                        cmbCliente.getValue().getIdCliente()
                );

                v.setPlaca(txtPlaca.getText().trim().toUpperCase());
                v.setVin(txtVin.getText().trim().toUpperCase());
                v.setMarca(txtMarca.getText().trim());
                v.setModelo(txtModelo.getText().trim());
                v.setAnio(Integer.parseInt(txtAnio.getText().trim()));
                v.setColor(txtColor.getText().trim().isEmpty()
                        ? null : txtColor.getText().trim());
                v.setKilometraje(
                        Integer.parseInt(txtKilometraje.getText().trim())
                );
                v.setCombustible(cmbCombustible.getValue());

                return v;
            }

            return null;
        });

        dialog.showAndWait().ifPresent(v -> {

            boolean resultado = editar
                    ? vehiculoDAO.actualizar(v)
                    : vehiculoDAO.insertar(v);

            if (resultado) {

                cargarVehiculos();

                mostrarAlerta(
                        "Éxito",
                        editar
                                ? "Vehículo actualizado correctamente."
                                : "Vehículo registrado correctamente.",
                        Alert.AlertType.INFORMATION
                );

            } else {

                mostrarAlerta(
                        "Error",
                        "No se pudo guardar el vehículo. "
                        + "Verifica que la placa y el VIN no estén registrados.",
                        Alert.AlertType.ERROR
                );
            }
        });
    }



    private boolean validarFormulario(
            ComboBox<Cliente> cliente,
            TextField placa,
            TextField vin,
            TextField marca,
            TextField modelo,
            TextField anio,
            TextField kilometraje,
            ComboBox<String> combustible) {

        if (cliente.getValue() == null
                || placa.getText().trim().isEmpty()
                || vin.getText().trim().isEmpty()
                || marca.getText().trim().isEmpty()
                || modelo.getText().trim().isEmpty()
                || anio.getText().trim().isEmpty()
                || kilometraje.getText().trim().isEmpty()
                || combustible.getValue() == null) {

            mostrarAlerta(
                    "Validación",
                    "Completa todos los campos obligatorios.",
                    Alert.AlertType.WARNING
            );

            return false;
        }

        try {

            int año = Integer.parseInt(anio.getText().trim());
            int km = Integer.parseInt(kilometraje.getText().trim());

            if (año < 1900 || año > 2100) {
                mostrarAlerta(
                        "Validación",
                        "Introduce un año válido.",
                        Alert.AlertType.WARNING
                );
                return false;
            }

            if (km < 0) {
                mostrarAlerta(
                        "Validación",
                        "El kilometraje no puede ser negativo.",
                        Alert.AlertType.WARNING
                );
                return false;
            }

        } catch (NumberFormatException e) {

            mostrarAlerta(
                    "Validación",
                    "El año y el kilometraje deben ser números.",
                    Alert.AlertType.WARNING
            );

            return false;
        }

        return true;
    }


    private void editarVehiculo() {

        Vehiculo seleccionado = tabla.getSelectionModel()
                .getSelectedItem();

        if (seleccionado == null) {

            mostrarAlerta(
                    "Selección",
                    "Selecciona un vehículo para editar.",
                    Alert.AlertType.WARNING
            );

            return;
        }

        mostrarFormulario(seleccionado);
    }



    private void cambiarEstado() {

        Vehiculo seleccionado = tabla.getSelectionModel()
                .getSelectedItem();

        if (seleccionado == null) {

            mostrarAlerta(
                    "Selección",
                    "Selecciona un vehículo.",
                    Alert.AlertType.WARNING
            );

            return;
        }

        String accion = seleccionado.isEstado()
                ? "desactivar"
                : "activar";

        Alert confirmacion = new Alert(
                Alert.AlertType.CONFIRMATION
        );

        confirmacion.setTitle("Confirmar acción");
        confirmacion.setHeaderText(
                "¿Deseas " + accion + " este vehículo?"
        );

        confirmacion.setContentText(
                seleccionado.getPlaca()
        );

        confirmacion.showAndWait().ifPresent(respuesta -> {

            if (respuesta == ButtonType.OK) {

                boolean resultado = seleccionado.isEstado()
                        ? vehiculoDAO.eliminar(
                                seleccionado.getIdVehiculo())
                        : vehiculoDAO.activar(
                                seleccionado.getIdVehiculo());

                if (resultado) {

                    cargarVehiculos();

                    mostrarAlerta(
                            "Éxito",
                            "Vehículo " + accion + " correctamente.",
                            Alert.AlertType.INFORMATION
                    );

                } else {

                    mostrarAlerta(
                            "Error",
                            "No se pudo " + accion + " el vehículo.",
                            Alert.AlertType.ERROR
                    );
                }
            }
        });
    }



    private Button crearBoton(String texto, boolean principal) {

        Button boton = new Button(texto);

        if (principal) {

            boton.setStyle(
                    "-fx-background-color: #E50914;"
                    + "-fx-text-fill: white;"
                    + "-fx-font-weight: bold;"
                    + "-fx-background-radius: 8;"
                    + "-fx-padding: 10 16;"
            );

        } else {

            boton.setStyle(
                    "-fx-background-color: #252932;"
                    + "-fx-text-fill: white;"
                    + "-fx-background-radius: 8;"
                    + "-fx-padding: 10 16;"
            );
        }

        boton.setCursor(javafx.scene.Cursor.HAND);

        return boton;
    }

    private void mostrarAlerta(
            String titulo,
            String mensaje,
            Alert.AlertType tipo) {

        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}