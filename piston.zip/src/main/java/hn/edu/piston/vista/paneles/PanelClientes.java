/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.vista.paneles;
import hn.edu.piston.daoimpl.ClienteDAOImpl;
import hn.edu.piston.modelo.Cliente;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Alexander
 */
public class PanelClientes extends BorderPane {

    private TableView<Cliente> tablaClientes;
    private final ClienteDAOImpl clienteDAO = new ClienteDAOImpl();

    private final ObservableList<Cliente> listaClientes =
            FXCollections.observableArrayList();

    public PanelClientes() {
        setPadding(new Insets(25));
        setStyle("-fx-background-color: #111318;");

        construirInterfaz();
        cargarClientes();
    }

    private void construirInterfaz() {

   

        Label titulo = new Label("GESTIÓN DE CLIENTES");
        titulo.setStyle(
                "-fx-text-fill: white;"
                + "-fx-font-size: 25px;"
                + "-fx-font-weight: bold;"
        );

        Label subtitulo = new Label(
                "Administración de clientes registrados en PISTON"
        );
        subtitulo.setStyle("-fx-text-fill: #9CA3AF;");

        VBox encabezado = new VBox(6, titulo, subtitulo);

 

        TextField txtBuscar = new TextField();
        txtBuscar.setPromptText("Buscar cliente...");
        txtBuscar.setPrefWidth(280);

        Button btnNuevo = new Button("+ NUEVO CLIENTE");

        btnNuevo.setStyle(
                "-fx-background-color: #E50914;"
                + "-fx-text-fill: white;"
                + "-fx-font-weight: bold;"
                + "-fx-background-radius: 8;"
                + "-fx-padding: 12 18;"
                + "-fx-cursor: hand;"
        );

        Button btnEstado = new Button("ACTIVAR / DESACTIVAR");

        btnEstado.setStyle(
                "-fx-background-color: #303640;"
                + "-fx-text-fill: white;"
                + "-fx-font-weight: bold;"
                + "-fx-background-radius: 8;"
                + "-fx-padding: 12 18;"
                + "-fx-cursor: hand;"
        );

        btnNuevo.setOnAction(e -> mostrarFormulario(null));

        btnEstado.setOnAction(e -> cambiarEstadoCliente());

        HBox herramientas = new HBox(
                15, txtBuscar, btnNuevo, btnEstado
        );

        herramientas.setAlignment(Pos.CENTER_LEFT);

        VBox superior = new VBox(25, encabezado, herramientas);
        setTop(superior);

      

        tablaClientes = new TableView<>();
        tablaClientes.setItems(listaClientes);

        tablaClientes.setPlaceholder(
                new Label("No hay clientes registrados")
        );

        tablaClientes.setStyle(
                "-fx-background-color: #171A20;"
                + "-fx-control-inner-background: #171A20;"
                + "-fx-text-fill: white;"
                + "-fx-border-color: #303640;"
        );

        TableColumn<Cliente, Integer> colId =
                new TableColumn<>("ID");

        colId.setCellValueFactory(
                new PropertyValueFactory<>("idCliente")
        );

        TableColumn<Cliente, String> colNombre =
                new TableColumn<>("Nombre");

        colNombre.setCellValueFactory(
                new PropertyValueFactory<>("nombre")
        );

        TableColumn<Cliente, String> colDni =
                new TableColumn<>("DNI");

        colDni.setCellValueFactory(
                new PropertyValueFactory<>("dni")
        );

        TableColumn<Cliente, String> colTelefono =
                new TableColumn<>("Teléfono");

        colTelefono.setCellValueFactory(
                new PropertyValueFactory<>("telefono")
        );

        TableColumn<Cliente, String> colCorreo =
                new TableColumn<>("Correo");

        colCorreo.setCellValueFactory(
                new PropertyValueFactory<>("correo")
        );

        TableColumn<Cliente, String> colEstado =
                new TableColumn<>("Estado");

        colEstado.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().isEstado()
                                ? "Activo"
                                : "Inactivo"
                )
        );

        tablaClientes.getColumns().addAll(
                colId,
                colNombre,
                colDni,
                colTelefono,
                colCorreo,
                colEstado
        );

        colId.setPrefWidth(70);
        colNombre.setPrefWidth(180);
        colDni.setPrefWidth(150);
        colTelefono.setPrefWidth(130);
        colCorreo.setPrefWidth(250);
        colEstado.setPrefWidth(100);

     

        tablaClientes.setRowFactory(tv -> {

            TableRow<Cliente> fila = new TableRow<>();

            fila.setOnMouseClicked(evento -> {

                if (evento.getClickCount() == 2
                        && !fila.isEmpty()) {

                    Cliente seleccionado = fila.getItem();

                    mostrarFormulario(seleccionado);
                }
            });

            return fila;
        });

        VBox contenido = new VBox(20, tablaClientes);

        VBox.setVgrow(tablaClientes, Priority.ALWAYS);

        setCenter(contenido);

        BorderPane.setMargin(
                superior,
                new Insets(0, 0, 25, 0)
        );

     

        txtBuscar.textProperty().addListener(
                (obs, anterior, nuevo) -> {

            String texto = nuevo.toLowerCase().trim();

            tablaClientes.setItems(
                    listaClientes.filtered(cliente ->
                            cliente.getNombre()
                                    .toLowerCase()
                                    .contains(texto)
                            ||
                            cliente.getDni()
                                    .toLowerCase()
                                    .contains(texto)
                    )
            );
        });
    }


    private void cargarClientes() {

        listaClientes.setAll(clienteDAO.listar());
    }



    private void mostrarFormulario(Cliente existente) {

        Dialog<Cliente> dialogo = new Dialog<>();

        dialogo.setTitle(
                existente == null
                        ? "Nuevo cliente"
                        : "Editar cliente"
        );

        dialogo.setHeaderText(
                existente == null
                        ? "Registro de cliente"
                        : "Modificar información del cliente"
        );

        ButtonType guardar = new ButtonType(
                "Guardar",
                ButtonBar.ButtonData.OK_DONE
        );

        dialogo.getDialogPane().getButtonTypes().addAll(
                guardar,
                ButtonType.CANCEL
        );

        TextField nombre = new TextField();
        TextField dni = new TextField();
        TextField telefono = new TextField();
        TextField correo = new TextField();
        TextField direccion = new TextField();

        // Cargar datos si es edición

        if (existente != null) {

            nombre.setText(existente.getNombre());
            dni.setText(existente.getDni());
            telefono.setText(existente.getTelefono());
            correo.setText(existente.getCorreo());
            direccion.setText(existente.getDireccion());
        }

        GridPane formulario = new GridPane();

        formulario.setHgap(10);
        formulario.setVgap(12);
        formulario.setPadding(new Insets(20));

        formulario.addRow(0, new Label("Nombre:"), nombre);
        formulario.addRow(1, new Label("DNI:"), dni);
        formulario.addRow(2, new Label("Teléfono:"), telefono);
        formulario.addRow(3, new Label("Correo:"), correo);
        formulario.addRow(4, new Label("Dirección:"), direccion);

        dialogo.getDialogPane().setContent(formulario);

        dialogo.setResultConverter(boton -> {

            if (boton == guardar) {

                Cliente cliente = existente == null
                        ? new Cliente()
                        : existente;

                cliente.setNombre(nombre.getText().trim());
                cliente.setDni(dni.getText().trim());
                cliente.setTelefono(telefono.getText().trim());
                cliente.setCorreo(correo.getText().trim());
                cliente.setDireccion(direccion.getText().trim());

                return cliente;
            }

            return null;
        });

        dialogo.showAndWait().ifPresent(cliente -> {

            // Validar campos obligatorios

            if (cliente.getNombre().isEmpty()
                    || cliente.getDni().isEmpty()) {

                mostrarAlerta(
                        "Nombre y DNI son obligatorios."
                );

                return;
            }

            // Evitar DNI duplicado

            boolean dniDuplicado = listaClientes.stream()
                    .anyMatch(c ->
                            c.getDni().equalsIgnoreCase(
                                    cliente.getDni()
                            )
                            &&
                            (existente == null
                                    || c.getIdCliente()
                                    != existente.getIdCliente())
                    );

            if (dniDuplicado) {

                mostrarAlerta(
                        "Ya existe un cliente con ese DNI."
                );

                return;
            }

            // Insertar o actualizar

            boolean resultado;

            if (existente == null) {

                resultado = clienteDAO.insertar(cliente);

            } else {

                resultado = clienteDAO.actualizar(cliente);
            }

            if (resultado) {

                cargarClientes();

                mostrarAlerta(
                        existente == null
                                ? "Cliente registrado correctamente."
                                : "Cliente actualizado correctamente."
                );

            } else {

                mostrarAlerta(
                        "No se pudo guardar el cliente."
                );
            }
        });
    }

  

    private void cambiarEstadoCliente() {

        Cliente seleccionado =
                tablaClientes.getSelectionModel()
                        .getSelectedItem();

        if (seleccionado == null) {

            mostrarAlerta(
                    "Seleccione un cliente de la tabla."
            );

            return;
        }

        boolean estaActivo = seleccionado.isEstado();

        Alert confirmacion = new Alert(
                Alert.AlertType.CONFIRMATION
        );

        confirmacion.setTitle(
                estaActivo
                        ? "Desactivar cliente"
                        : "Activar cliente"
        );

        confirmacion.setHeaderText(
                estaActivo
                        ? "¿Desea desactivar este cliente?"
                        : "¿Desea activar este cliente?"
        );

        confirmacion.setContentText(
                seleccionado.getNombre()
        );

        confirmacion.showAndWait().ifPresent(respuesta -> {

            if (respuesta == ButtonType.OK) {

                boolean resultado;

                if (estaActivo) {

                    resultado = clienteDAO.eliminar(
                            seleccionado.getIdCliente()
                    );

                } else {

                    resultado = clienteDAO.activar(
                            seleccionado.getIdCliente()
                    );
                }

                if (resultado) {

                    cargarClientes();

                    mostrarAlerta(
                            estaActivo
                                    ? "Cliente desactivado correctamente."
                                    : "Cliente activado correctamente."
                    );

                } else {

                    mostrarAlerta(
                            "No se pudo actualizar el estado del cliente."
                    );
                }
            }
        });
    }


    private void mostrarAlerta(String mensaje) {

        Alert alerta = new Alert(
                Alert.AlertType.INFORMATION
        );

        alerta.setTitle("P.I.S.T.O.N.");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }
}