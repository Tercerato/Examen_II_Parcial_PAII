/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.DiagnosticoDAO;
import hn.edu.piston.modelo.Diagnostico;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class DiagnosticoDAOImpl implements DiagnosticoDAO {

    @Override
    public List<Diagnostico> listar() {

        List<Diagnostico> lista = new ArrayList<>();

        String sql = """
                SELECT *
                FROM DIAGNOSTICOS
                ORDER BY id_diagnostico DESC
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearDiagnostico(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    @Override
    public List<Diagnostico> listarPorOrden(int idOrden) {

        List<Diagnostico> lista = new ArrayList<>();

        String sql = """
                SELECT *
                FROM DIAGNOSTICOS
                WHERE id_orden = ?
                ORDER BY fecha DESC
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idOrden);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    lista.add(mapearDiagnostico(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    @Override
    public boolean insertar(Diagnostico diagnostico) {

        String sql = """
                INSERT INTO DIAGNOSTICOS
                (id_orden, descripcion, evidencia)
                VALUES (?, ?, ?)
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, diagnostico.getIdOrden());
            ps.setString(2, diagnostico.getDescripcion());
            ps.setString(3, diagnostico.getEvidencia());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Diagnostico mapearDiagnostico(ResultSet rs)
            throws SQLException {

        Diagnostico diagnostico = new Diagnostico();

        diagnostico.setIdDiagnostico(
                rs.getInt("id_diagnostico"));

        diagnostico.setIdOrden(
                rs.getInt("id_orden"));

        diagnostico.setDescripcion(
                rs.getString("descripcion"));

        diagnostico.setEvidencia(
                rs.getString("evidencia"));

        Timestamp fecha = rs.getTimestamp("fecha");

        if (fecha != null) {
            diagnostico.setFecha(
                    fecha.toLocalDateTime());
        }

        return diagnostico;
    }
}