/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.OrdenTrabajoDAO;
import hn.edu.piston.modelo.OrdenTrabajo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class OrdenTrabajoDAOImpl implements OrdenTrabajoDAO {

    @Override
    public List<OrdenTrabajo> listar() {

        List<OrdenTrabajo> lista = new ArrayList<>();

        String sql = "SELECT O.id_orden, O.id_vehiculo, "
                + "O.fecha_inicio, O.fecha_fin, O.kilometraje, "
                + "O.sintomas, O.diagnostico_preliminar, O.estado, "
                + "V.placa, V.marca, V.modelo, C.nombre AS cliente "
                + "FROM ORDENES_TRABAJO O "
                + "INNER JOIN VEHICULOS V ON O.id_vehiculo = V.id_vehiculo "
                + "INNER JOIN CLIENTES C ON V.id_cliente = C.id_cliente "
                + "ORDER BY O.id_orden DESC";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                OrdenTrabajo o = mapearOrden(rs);
                lista.add(o);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    @Override
    public OrdenTrabajo buscarPorId(int id) {

        String sql = "SELECT O.id_orden, O.id_vehiculo, "
                + "O.fecha_inicio, O.fecha_fin, O.kilometraje, "
                + "O.sintomas, O.diagnostico_preliminar, O.estado, "
                + "V.placa, V.marca, V.modelo, C.nombre AS cliente "
                + "FROM ORDENES_TRABAJO O "
                + "INNER JOIN VEHICULOS V ON O.id_vehiculo = V.id_vehiculo "
                + "INNER JOIN CLIENTES C ON V.id_cliente = C.id_cliente "
                + "WHERE O.id_orden = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapearOrden(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insertar(OrdenTrabajo orden) {

        String sql = "INSERT INTO ORDENES_TRABAJO "
                + "(id_vehiculo, kilometraje, sintomas, "
                + "diagnostico_preliminar) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, orden.getIdVehiculo());
            ps.setInt(2, orden.getKilometraje());
            ps.setString(3, orden.getSintomas());
            ps.setString(4, orden.getDiagnosticoPreliminar());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean actualizar(OrdenTrabajo orden) {

        String sql = "UPDATE ORDENES_TRABAJO "
                + "SET sintomas = ?, diagnostico_preliminar = ?, "
                + "kilometraje = ? "
                + "WHERE id_orden = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, orden.getSintomas());
            ps.setString(2, orden.getDiagnosticoPreliminar());
            ps.setInt(3, orden.getKilometraje());
            ps.setInt(4, orden.getIdOrden());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean cambiarEstado(int id, String estado) {

        String sql = "UPDATE ORDENES_TRABAJO "
                + "SET estado = ? WHERE id_orden = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, estado);
            ps.setInt(2, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private OrdenTrabajo mapearOrden(ResultSet rs)
            throws SQLException {

        OrdenTrabajo o = new OrdenTrabajo();

        o.setIdOrden(rs.getInt("id_orden"));
        o.setIdVehiculo(rs.getInt("id_vehiculo"));

        Timestamp inicio = rs.getTimestamp("fecha_inicio");
        if (inicio != null) {
            o.setFechaInicio(inicio.toLocalDateTime());
        }

        Timestamp fin = rs.getTimestamp("fecha_fin");
        if (fin != null) {
            o.setFechaFin(fin.toLocalDateTime());
        }

        o.setKilometraje(rs.getInt("kilometraje"));
        o.setSintomas(rs.getString("sintomas"));
        o.setDiagnosticoPreliminar(
                rs.getString("diagnostico_preliminar")
        );
        o.setEstado(rs.getString("estado"));

        o.setPlaca(rs.getString("placa"));
        o.setMarca(rs.getString("marca"));
        o.setModelo(rs.getString("modelo"));
        o.setCliente(rs.getString("cliente"));

        return o;
    }
}