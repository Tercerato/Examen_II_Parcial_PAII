/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.VehiculoDAO;
import hn.edu.piston.modelo.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class VehiculoDAOImpl implements VehiculoDAO {

   @Override
public List<Vehiculo> listar() {

    List<Vehiculo> lista = new ArrayList<>();

    String sql = "SELECT "
            + "V.id_vehiculo, "
            + "V.id_cliente, "
            + "C.nombre AS propietario, "
            + "V.placa, "
            + "V.vin, "
            + "V.marca, "
            + "V.modelo, "
            + "V.anio, "
            + "V.color, "
            + "V.kilometraje, "
            + "V.combustible, "
            + "V.estado "
            + "FROM VEHICULOS V "
            + "INNER JOIN CLIENTES C "
            + "ON V.id_cliente = C.id_cliente";

    try (Connection conn = ConexionDB.getConexion();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

            Vehiculo v = new Vehiculo();

            v.setIdVehiculo(rs.getInt("id_vehiculo"));
            v.setIdCliente(rs.getInt("id_cliente"));
            v.setPropietario(rs.getString("propietario"));
            v.setPlaca(rs.getString("placa"));
            v.setVin(rs.getString("vin"));
            v.setMarca(rs.getString("marca"));
            v.setModelo(rs.getString("modelo"));
            v.setAnio(rs.getInt("anio"));
            v.setColor(rs.getString("color"));
            v.setKilometraje(rs.getInt("kilometraje"));
            v.setCombustible(rs.getString("combustible"));
            v.setEstado(rs.getBoolean("estado"));

            lista.add(v);
        }

    } catch (SQLException e) {
        System.err.println(
                "Error al listar vehículos: " + e.getMessage()
        );
    }

    return lista;
}

    @Override
    public Vehiculo buscarPorId(int idVehiculo) {

        Vehiculo v = null;

        String sql = "SELECT * FROM VEHICULOS WHERE id_vehiculo = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idVehiculo);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    v = new Vehiculo();

                    v.setIdVehiculo(rs.getInt("id_vehiculo"));
                    v.setIdCliente(rs.getInt("id_cliente"));
                    v.setPlaca(rs.getString("placa"));
                    v.setVin(rs.getString("vin"));
                    v.setMarca(rs.getString("marca"));
                    v.setModelo(rs.getString("modelo"));
                    v.setAnio(rs.getInt("anio"));
                    v.setColor(rs.getString("color"));
                    v.setKilometraje(rs.getInt("kilometraje"));
                    v.setCombustible(rs.getString("combustible"));
                    v.setEstado(rs.getBoolean("estado"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar vehículo: " + e.getMessage());
        }

        return v;
    }

    @Override
    public boolean insertar(Vehiculo vehiculo) {

        String sql = "INSERT INTO VEHICULOS "
                + "(id_cliente, placa, vin, marca, modelo, anio, "
                + "color, kilometraje, combustible, estado) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, vehiculo.getIdCliente());
            ps.setString(2, vehiculo.getPlaca());
            ps.setString(3, vehiculo.getVin());
            ps.setString(4, vehiculo.getMarca());
            ps.setString(5, vehiculo.getModelo());
            ps.setInt(6, vehiculo.getAnio());
            ps.setString(7, vehiculo.getColor());
            ps.setInt(8, vehiculo.getKilometraje());
            ps.setString(9, vehiculo.getCombustible());
            ps.setBoolean(10, true);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar vehículo: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean actualizar(Vehiculo vehiculo) {

        String sql = "UPDATE VEHICULOS SET "
                + "id_cliente = ?, placa = ?, vin = ?, marca = ?, "
                + "modelo = ?, anio = ?, color = ?, kilometraje = ?, "
                + "combustible = ? "
                + "WHERE id_vehiculo = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, vehiculo.getIdCliente());
            ps.setString(2, vehiculo.getPlaca());
            ps.setString(3, vehiculo.getVin());
            ps.setString(4, vehiculo.getMarca());
            ps.setString(5, vehiculo.getModelo());
            ps.setInt(6, vehiculo.getAnio());
            ps.setString(7, vehiculo.getColor());
            ps.setInt(8, vehiculo.getKilometraje());
            ps.setString(9, vehiculo.getCombustible());
            ps.setInt(10, vehiculo.getIdVehiculo());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar vehículo: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean eliminar(int idVehiculo) {

        String sql = "UPDATE VEHICULOS SET estado = 0 "
                + "WHERE id_vehiculo = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idVehiculo);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al desactivar vehículo: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean activar(int idVehiculo) {

        String sql = "UPDATE VEHICULOS SET estado = 1 "
                + "WHERE id_vehiculo = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idVehiculo);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al activar vehículo: " + e.getMessage());
            return false;
        }
    }
}