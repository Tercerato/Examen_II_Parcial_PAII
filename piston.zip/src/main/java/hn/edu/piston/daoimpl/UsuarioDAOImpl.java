/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.dao.impl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.UsuarioDAO;
import hn.edu.piston.modelo.Usuario;
import java.sql.Types;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class UsuarioDAOImpl implements UsuarioDAO {

    @Override
    public Usuario autenticar(String usuario, String contrasena) {

        String sql = "SELECT id_usuario, usuario, contrasena, "
                + "rol, id_mecanico, estado "
                + "FROM USUARIOS "
                + "WHERE usuario = ? AND contrasena = ? AND estado = 1";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, contrasena);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearUsuario(rs);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al autenticar: " + e.getMessage());
        }

        return null;
    }

    @Override
    public List<Usuario> listar() {

        List<Usuario> lista = new ArrayList<>();

        String sql = "SELECT id_usuario, usuario, contrasena, "
                + "rol, id_mecanico, estado FROM USUARIOS";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearUsuario(rs));
            }

        } catch (SQLException e) {
            System.err.println("Error al listar usuarios: " + e.getMessage());
        }

        return lista;
    }

    @Override
    public boolean registrar(Usuario usuario) {

        String sql = "INSERT INTO USUARIOS "
                + "(usuario, contrasena, rol, id_mecanico, estado) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usuario.getUsuario());
            ps.setString(2, usuario.getContrasena());
            ps.setString(3, usuario.getRol());

            if (usuario.getIdMecanico() == null) {
                ps.setNull(4, Types.INTEGER);
            } else {
                ps.setInt(4, usuario.getIdMecanico());
            }

            ps.setBoolean(5, usuario.isEstado());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean actualizar(Usuario usuario) {

        String sql = "UPDATE USUARIOS SET usuario=?, contrasena=?, "
                + "rol=?, id_mecanico=? WHERE id_usuario=?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usuario.getUsuario());
            ps.setString(2, usuario.getContrasena());
            ps.setString(3, usuario.getRol());

            if (usuario.getIdMecanico() == null) {
                ps.setNull(4, Types.INTEGER);
            } else {
                ps.setInt(4, usuario.getIdMecanico());
            }

            ps.setInt(5, usuario.getIdUsuario());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean cambiarEstado(int idUsuario, boolean estado) {

        String sql = "UPDATE USUARIOS SET estado=? WHERE id_usuario=?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, estado);
            ps.setInt(2, idUsuario);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al cambiar estado: " + e.getMessage());
            return false;
        }
    }

    private Usuario mapearUsuario(ResultSet rs) throws SQLException {

        Usuario u = new Usuario();

        u.setIdUsuario(rs.getInt("id_usuario"));
        u.setUsuario(rs.getString("usuario"));
        u.setContrasena(rs.getString("contrasena"));
        u.setRol(rs.getString("rol"));

        int idMecanico = rs.getInt("id_mecanico");

        if (rs.wasNull()) {
            u.setIdMecanico(null);
        } else {
            u.setIdMecanico(idMecanico);
        }

        u.setEstado(rs.getBoolean("estado"));

        return u;
    }
}