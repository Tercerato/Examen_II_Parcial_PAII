/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.ServicioDAO;
import hn.edu.piston.modelo.Servicio;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class ServicioDAOImpl implements ServicioDAO {

    @Override
    public List<Servicio> listar() {

        List<Servicio> lista = new ArrayList<>();

        String sql = """
                SELECT *
                FROM SERVICIOS
                ORDER BY id_servicio DESC
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearServicio(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    @Override
    public Servicio buscarPorId(int id) {

        String sql = """
                SELECT *
                FROM SERVICIOS
                WHERE id_servicio = ?
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearServicio(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insertar(Servicio servicio) {

        String sql = """
                INSERT INTO SERVICIOS
                (codigo, nombre, descripcion, nivel_complejidad,
                 costo_mano_obra, tiempo_estimado, estado)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, servicio.getCodigo());
            ps.setString(2, servicio.getNombre());
            ps.setString(3, servicio.getDescripcion());
            ps.setInt(4, servicio.getNivelComplejidad());
            ps.setDouble(5, servicio.getCostoManoObra());
            ps.setInt(6, servicio.getTiempoEstimado());
            ps.setString(7, servicio.getEstado());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizar(Servicio servicio) {

        String sql = """
                UPDATE SERVICIOS
                SET codigo = ?, nombre = ?, descripcion = ?,
                    nivel_complejidad = ?, costo_mano_obra = ?,
                    tiempo_estimado = ?, estado = ?
                WHERE id_servicio = ?
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, servicio.getCodigo());
            ps.setString(2, servicio.getNombre());
            ps.setString(3, servicio.getDescripcion());
            ps.setInt(4, servicio.getNivelComplejidad());
            ps.setDouble(5, servicio.getCostoManoObra());
            ps.setInt(6, servicio.getTiempoEstimado());
            ps.setString(7, servicio.getEstado());
            ps.setInt(8, servicio.getIdServicio());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean cambiarEstado(int id, String estado) {

        String sql = """
                UPDATE SERVICIOS
                SET estado = ?
                WHERE id_servicio = ?
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, estado);
            ps.setInt(2, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Servicio mapearServicio(ResultSet rs)
            throws SQLException {

        Servicio servicio = new Servicio();

        servicio.setIdServicio(rs.getInt("id_servicio"));
        servicio.setCodigo(rs.getString("codigo"));
        servicio.setNombre(rs.getString("nombre"));
        servicio.setDescripcion(rs.getString("descripcion"));
        servicio.setNivelComplejidad(
                rs.getInt("nivel_complejidad"));
        servicio.setCostoManoObra(
                rs.getDouble("costo_mano_obra"));
        servicio.setTiempoEstimado(
                rs.getInt("tiempo_estimado"));
        servicio.setEstado(rs.getString("estado"));

        return servicio;
    }
}