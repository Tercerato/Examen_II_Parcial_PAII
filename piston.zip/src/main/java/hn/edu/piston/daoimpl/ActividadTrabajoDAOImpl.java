/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.ActividadTrabajoDAO;
import hn.edu.piston.modelo.ActividadTrabajo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class ActividadTrabajoDAOImpl implements ActividadTrabajoDAO {

@Override
public List<ActividadTrabajo> listarPorOrden(int idOrden) {

    List<ActividadTrabajo> lista = new ArrayList<>();

    String sql = """
        SELECT
            A.id_actividad,
            A.id_orden,
            A.id_mecanico,
            M.nombre AS nombre_mecanico,
            A.descripcion,
            A.estado
        FROM ACTIVIDADES_TRABAJO A
        INNER JOIN MECANICOS M
            ON A.id_mecanico = M.id_mecanico
        WHERE A.id_orden = ?
        ORDER BY A.id_actividad DESC
    """;

    try (PreparedStatement ps =
            ConexionDB.getConexion().prepareStatement(sql)) {

        ps.setInt(1, idOrden);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            ActividadTrabajo actividad = new ActividadTrabajo();

            actividad.setIdActividad(
                    rs.getInt("id_actividad"));

            actividad.setIdOrden(
                    rs.getInt("id_orden"));

            actividad.setIdMecanico(
                    rs.getInt("id_mecanico"));

            actividad.setNombreMecanico(
                    rs.getString("nombre_mecanico"));

            actividad.setDescripcion(
                    rs.getString("descripcion"));

            actividad.setEstado(
                    rs.getString("estado"));

            lista.add(actividad);
        }

    } catch (SQLException e) {
        System.err.println(
                "Error al listar actividades: " + e.getMessage());
    }

    return lista;
}

    @Override
    public boolean insertar(ActividadTrabajo actividad) {

        String sql = """
            INSERT INTO ACTIVIDADES_TRABAJO
            (id_orden, id_mecanico, descripcion)
            VALUES (?, ?, ?)
        """;

        try (PreparedStatement ps =
                ConexionDB.getConexion().prepareStatement(sql)) {

            ps.setInt(1, actividad.getIdOrden());
            ps.setInt(2, actividad.getIdMecanico());
            ps.setString(3, actividad.getDescripcion());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar actividad: "
                    + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean actualizarEstado(int idActividad, String estado) {

        String sql = """
            UPDATE ACTIVIDADES_TRABAJO
            SET estado = ?
            WHERE id_actividad = ?
        """;

        try (PreparedStatement ps =
                ConexionDB.getConexion().prepareStatement(sql)) {

            ps.setString(1, estado);
            ps.setInt(2, idActividad);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar actividad: "
                    + e.getMessage());
            return false;
        }
    }
}
