/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.MecanicoDAO;
import hn.edu.piston.modelo.Mecanico;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class MecanicoDAOImpl implements MecanicoDAO {

    @Override
    public List<Mecanico> listar() {
        List<Mecanico> lista = new ArrayList<>();

        String sql = "SELECT id_mecanico, nombre, especialidad, telefono, estado "
                   + "FROM MECANICOS";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Mecanico m = new Mecanico();

                m.setIdMecanico(rs.getInt("id_mecanico"));
                m.setNombre(rs.getString("nombre"));
                m.setEspecialidad(rs.getString("especialidad"));
                m.setTelefono(rs.getString("telefono"));
                m.setEstado(rs.getBoolean("estado"));

                lista.add(m);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    @Override
    public Mecanico buscarPorId(int id) {
        String sql = "SELECT id_mecanico, nombre, especialidad, telefono, estado "
                   + "FROM MECANICOS WHERE id_mecanico = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Mecanico m = new Mecanico();

                    m.setIdMecanico(rs.getInt("id_mecanico"));
                    m.setNombre(rs.getString("nombre"));
                    m.setEspecialidad(rs.getString("especialidad"));
                    m.setTelefono(rs.getString("telefono"));
                    m.setEstado(rs.getBoolean("estado"));

                    return m;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insertar(Mecanico m) {
        String sql = "INSERT INTO MECANICOS "
                   + "(nombre, especialidad, telefono) "
                   + "VALUES (?, ?, ?)";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, m.getNombre());
            ps.setString(2, m.getEspecialidad());
            ps.setString(3, m.getTelefono());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean actualizar(Mecanico m) {
        String sql = "UPDATE MECANICOS SET nombre = ?, "
                   + "especialidad = ?, telefono = ? "
                   + "WHERE id_mecanico = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, m.getNombre());
            ps.setString(2, m.getEspecialidad());
            ps.setString(3, m.getTelefono());
            ps.setInt(4, m.getIdMecanico());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean eliminar(int id) {
        String sql = "UPDATE MECANICOS SET estado = 0 "
                   + "WHERE id_mecanico = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean activar(int id) {
        String sql = "UPDATE MECANICOS SET estado = 1 "
                   + "WHERE id_mecanico = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}