/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.RepuestoDAO;
import hn.edu.piston.modelo.Repuesto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class RepuestoDAOImpl implements RepuestoDAO {

    @Override
    public List<Repuesto> listar() {

        List<Repuesto> lista = new ArrayList<>();

        String sql = "SELECT id_repuesto, id_proveedor, codigo, "
                + "nombre, descripcion, stock, stock_minimo, "
                + "costo_unitario, estado FROM REPUESTOS "
                + "ORDER BY id_repuesto DESC";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearRepuesto(rs));
            }

        } catch (SQLException e) {
            System.err.println("Error al listar repuestos: "
                    + e.getMessage());
        }

        return lista;
    }

    @Override
    public Repuesto buscarPorId(int idRepuesto) {

        Repuesto repuesto = null;

        String sql = "SELECT * FROM REPUESTOS "
                + "WHERE id_repuesto = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idRepuesto);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    repuesto = mapearRepuesto(rs);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar repuesto: "
                    + e.getMessage());
        }

        return repuesto;
    }

    @Override
    public boolean insertar(Repuesto repuesto) {

        String sql = "INSERT INTO REPUESTOS "
                + "(id_proveedor, codigo, nombre, descripcion, "
                + "stock, stock_minimo, costo_unitario, estado) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, repuesto.getIdProveedor());
            ps.setString(2, repuesto.getCodigo());
            ps.setString(3, repuesto.getNombre());
            ps.setString(4, repuesto.getDescripcion());
            ps.setInt(5, repuesto.getStock());
            ps.setInt(6, repuesto.getStockMinimo());
            ps.setDouble(7, repuesto.getCostoUnitario());
            ps.setBoolean(8, true);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar repuesto: "
                    + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean actualizar(Repuesto repuesto) {

        String sql = "UPDATE REPUESTOS SET "
                + "id_proveedor = ?, codigo = ?, nombre = ?, "
                + "descripcion = ?, stock = ?, stock_minimo = ?, "
                + "costo_unitario = ? "
                + "WHERE id_repuesto = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, repuesto.getIdProveedor());
            ps.setString(2, repuesto.getCodigo());
            ps.setString(3, repuesto.getNombre());
            ps.setString(4, repuesto.getDescripcion());
            ps.setInt(5, repuesto.getStock());
            ps.setInt(6, repuesto.getStockMinimo());
            ps.setDouble(7, repuesto.getCostoUnitario());
            ps.setInt(8, repuesto.getIdRepuesto());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar repuesto: "
                    + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean eliminar(int idRepuesto) {

        String sql = "UPDATE REPUESTOS SET estado = 0 "
                + "WHERE id_repuesto = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idRepuesto);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al desactivar repuesto: "
                    + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean activar(int idRepuesto) {

        String sql = "UPDATE REPUESTOS SET estado = 1 "
                + "WHERE id_repuesto = ?";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idRepuesto);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al activar repuesto: "
                    + e.getMessage());
            return false;
        }
    }

    private Repuesto mapearRepuesto(ResultSet rs)
            throws SQLException {

        Repuesto r = new Repuesto();

        r.setIdRepuesto(rs.getInt("id_repuesto"));
        r.setIdProveedor(rs.getInt("id_proveedor"));
        r.setCodigo(rs.getString("codigo"));
        r.setNombre(rs.getString("nombre"));
        r.setDescripcion(rs.getString("descripcion"));
        r.setStock(rs.getInt("stock"));
        r.setStockMinimo(rs.getInt("stock_minimo"));
        r.setCostoUnitario(rs.getDouble("costo_unitario"));
        r.setEstado(rs.getBoolean("estado"));

        return r;
    }
}