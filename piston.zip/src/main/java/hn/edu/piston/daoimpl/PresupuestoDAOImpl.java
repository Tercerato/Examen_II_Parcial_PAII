/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hn.edu.piston.daoimpl;
import hn.edu.piston.conexion.ConexionDB;
import hn.edu.piston.dao.PresupuestoDAO;
import hn.edu.piston.modelo.Presupuesto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Alexander
 */
public class PresupuestoDAOImpl implements PresupuestoDAO {

    @Override
    public List<Presupuesto> listar() {

        List<Presupuesto> lista = new ArrayList<>();

        String sql = "SELECT * FROM PRESUPUESTOS ORDER BY id_presupuesto DESC";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearPresupuesto(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    @Override
    public Presupuesto buscarPorId(int idPresupuesto) {

        String sql = "SELECT * FROM PRESUPUESTOS WHERE id_presupuesto = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idPresupuesto);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearPresupuesto(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public Presupuesto buscarPorOrden(int idOrden) {

        String sql = "SELECT * FROM PRESUPUESTOS WHERE id_orden = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idOrden);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearPresupuesto(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insertar(Presupuesto p) {

        String sql = """
            INSERT INTO PRESUPUESTOS
            (
                id_orden,
                horas_mano_obra,
                costo_hora,
                subtotal_servicios,
                subtotal_repuestos,
                descuento,
                porcentaje_impuesto,
                impuesto,
                total,
                estado
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, p.getIdOrden());
            ps.setDouble(2, p.getHorasManoObra());
            ps.setDouble(3, p.getCostoHora());
            ps.setDouble(4, p.getSubtotalServicios());
            ps.setDouble(5, p.getSubtotalRepuestos());
            ps.setDouble(6, p.getDescuento());
            ps.setDouble(7, p.getPorcentajeImpuesto());
            ps.setDouble(8, p.getImpuesto());
            ps.setDouble(9, p.getTotal());
            ps.setString(10, p.getEstado());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizarEstado(int idPresupuesto, String estado) {

        String sql = """
            UPDATE PRESUPUESTOS
            SET estado = ?
            WHERE id_presupuesto = ?
            """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, estado);
            ps.setInt(2, idPresupuesto);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Presupuesto mapearPresupuesto(ResultSet rs)
            throws SQLException {

        Presupuesto p = new Presupuesto();

        p.setIdPresupuesto(rs.getInt("id_presupuesto"));
        p.setIdOrden(rs.getInt("id_orden"));
        p.setHorasManoObra(rs.getDouble("horas_mano_obra"));
        p.setCostoHora(rs.getDouble("costo_hora"));
        p.setSubtotalServicios(rs.getDouble("subtotal_servicios"));
        p.setSubtotalRepuestos(rs.getDouble("subtotal_repuestos"));
        p.setDescuento(rs.getDouble("descuento"));
        p.setPorcentajeImpuesto(rs.getDouble("porcentaje_impuesto"));
        p.setImpuesto(rs.getDouble("impuesto"));
        p.setTotal(rs.getDouble("total"));
        p.setEstado(rs.getString("estado"));

        Timestamp fecha = rs.getTimestamp("fecha");

        if (fecha != null) {
            p.setFecha(fecha.toLocalDateTime());
        }

        return p;
    }
}
